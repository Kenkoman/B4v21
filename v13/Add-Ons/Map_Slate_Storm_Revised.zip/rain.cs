datablock AudioProfile(RainSound)
{
   filename    = "./rainsound.ogg";
   description = AudioLooping2d;
};

datablock PrecipitationData(HeavyRain)
{
   soundProfile = "RainSound";

   dropTexture = "./rain";
   splashTexture = "./water_splash";
   dropSize = 0.75;
   splashSize = 0.2;
   useTrueBillboards = false;
   splashMS = 250;
};