//super human, just enough jet for a big leap
datablock PlayerData(PlayerJumpJet : PlayerStandardArmor)
{
	minJetEnergy = 10;
	jetEnergyDrain = 10;
	canJet = 1;

	rechargeRate = 3.0;

	uiName = "Jump-Jet Player";
	showEnergyBar = false;
};