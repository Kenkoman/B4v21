//particles_FX Cans
//the datablocks for these particles are part of the game, this file just changes them slightly to make them placeable with the wrench

blinkPaintEmitter.uiName          = "FX Can - Blink";
blinkPaintExplosionEmitter.uiName = "FX Can - Blink Bubble";
blinkPaintDropletEmitter.uiName   = "FX Can - Blink Droplet";

chromePaintEmitter.uiName          = "FX Can - Chrome";
chromePaintExplosionEmitter.uiName = "FX Can - Chrome Bubble";
chromePaintDropletEmitter.uiName   = "FX Can - Chrome Droplet";

flatPaintEmitter.uiName          = "FX Can - Flat";
flatPaintExplosionEmitter.uiName = "FX Can - Flat Hit";

glowPaintEmitter.uiName          = "FX Can - Glow";
glowPaintExplosionEmitter.uiName = "FX Can - Glow Bubble";
glowPaintDropletEmitter.uiName   = "FX Can - Glow Droplet";

jelloPaintEmitter.uiName          = "FX Can - Undulo";
jelloPaintExplosionEmitter.uiName = "FX Can - Undulo Bubble";
jelloPaintDropletEmitter.uiName   = "FX Can - Undulo Droplet";

pearlPaintEmitter.uiName          = "FX Can - Pearl";
pearlPaintExplosionEmitter.uiName = "FX Can - Pearl Bubble";
pearlPaintDropletEmitter.uiName   = "FX Can - Pearl Droplet";

rainbowPaintEmitter.uiName          = "FX Can - Rainbow";
rainbowPaintExplosionEmitter.uiName = "FX Can - Rainbow Bubble";
rainbowPaintDropletEmitter.uiName   = "FX Can - Rainbow Droplet";

stablePaintEmitter.uiName          = "FX Can - Stable";
stablePaintExplosionEmitter.uiName = "FX Can - Stable Bubble";
stablePaintDropletEmitter.uiName   = "FX Can - Stable Droplet";

swirlPaintEmitter.uiName          = "FX Can - Swirl";
swirlPaintExplosionEmitter.uiName = "FX Can - Swirl Bubble";
swirlPaintDropletEmitter.uiName   = "FX Can - Swirl Droplet";