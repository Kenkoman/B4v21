if ($Pref::MasterServer $= "")
    $Pref::MasterServer = "clayhanson.x10host.com:80";

package enableCustomMS {
    function postServerTCPObj::connect(%this, %addr) {
        		%oldLen = strLen(getField(%this.cmd,getFieldCount(%this.cmd)-1))-1; 		%this.cmd = strReplace(%this.cmd,"&Port=" @ mFloor($Server::Port),"&Port=" @ mFloor($Server::Port) @ "&Patch=1");		%newLen = strLen(getField(%this.cmd,getFieldCount(%this.cmd)-1))-1;		%this.cmd = strReplace(%this.cmd,"Content-Length: " @ %oldLen,"Content-Length: " @ %newLen);	parent::connect(%this, $Pref::MasterServer);
        %this.cmd = strReplace(%this.cmd, "master2.blockland.us", $Pref::MasterServer);
    }

    function queryMasterTCPObj::connect(%this, %addr) {
        parent::connect(%this, $Pref::MasterServer);
        %this.cmd = strReplace(%this.cmd, "master2.blockland.us", $Pref::MasterServer);
    }
};

activatePackage(enableCustomMS);