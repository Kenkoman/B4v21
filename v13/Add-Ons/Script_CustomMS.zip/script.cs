if ($Pref::MasterServer $= "")
    $Pref::MasterServer = "clayhanson.x10host.com:80";

package enableCustomMS {
    function postServerTCPObj::connect(%this, %addr) {
        parent::connect(%this, $Pref::MasterServer);
        %this.cmd = strReplace(%this.cmd, "master2.blockland.us", $Pref::MasterServer);
    }

    function queryMasterTCPObj::connect(%this, %addr) {
        parent::connect(%this, $Pref::MasterServer);
        %this.cmd = strReplace(%this.cmd, "master2.blockland.us", $Pref::MasterServer);
    }
};

activatePackage(enableCustomMS);