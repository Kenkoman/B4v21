datablock ParticleEmitterData(RowboatFoamEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 80;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlayerFoamParticle";

   useEmitterColors = true;

   uiName = "Rowboat Foam";
};

datablock PlayerData(RowBoatArmor : PlayerStandardArmor)
{
	cameraVerticalOffset = 3;
	shapefile = "./Rowboat.dts";
	canJet = 0;
	mass = 120;
   drag = 0.03;
   density = 0.6;
   runSurfaceAngle = 1;
   jumpSurfaceAngle = 1;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxForwardCrouchSpeed = 0;
   maxSideSpeed = 0;
   maxSideCrouchSpeed = 0;
   maxStepHeight = 0;
   maxUnderwaterSideSpeed = 0;

	uiName = "Rowboat";
	showEnergyBar = false;
	
   jumpForce = 0;
   jumpEnergyDrain = 10000;
   minJumpEnergy = 10000;
   jumpDelay = 127;
   minJumpSpeed = 0;
   maxJumpSpeed = 0;
	
	rideable = true;
	canRide = false;
	paintable = true;
	
   boundingBox			= vectorScale("2.5 2.5 1", 4); 
   crouchBoundingBox	= vectorScale("2.5 2.5 1", 4);
	
   lookUpLimit = 0.65;
	lookDownLimit = 0.45;
	
   numMountPoints = 3;
   mountThread[0] = "sit";
   mountThread[1] = "sit";
   mountThread[2] = "sit";

   splashEmitter[0] = RowboatFoamEmitter;
   splashEmitter[1] = RowboatFoamEmitter;
   splashEmitter[2] = RowboatFoamEmitter;
   
   upMaxSpeed = 1;
   upResistSpeed = 1;
   upResistFactor = 1;
   maxdamage = 260;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   useCustomPainEffects = true;
   PainHighImage = "";
   PainMidImage  = "";
   PainLowImage  = "";
   painSound     = "";
   deathSound    = "";
};
