//super hero-ish, enough to jump 3 stories or so
datablock PlayerData(PlayerLeapJet : PlayerStandardArmor)
{
	minJetEnergy = 5;
	jetEnergyDrain = 5;
	canJet = 1;

	rechargeRate = 1.5;

	uiName = "Leap-Jet Player";
	showEnergyBar = true;
};