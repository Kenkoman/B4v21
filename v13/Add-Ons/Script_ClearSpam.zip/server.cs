function serverCmdClearSpamBricks(%client)
{
   if(!%client.isAdmin)
      return;
   
   if($Server::BrickCount > 0)
		messageAll('MsgClearBricks', "\c3" @ %client.getPlayerName() @ "\c0 cleared spam bricks.");

   //loop through all bricks
   %groupCount = MainBrickGroup.getCount();
   for(%i = 0; %i < %groupCount; %i++)
   {
      %group = MainBrickGroup.getObject(%i);
      %count = %group.getCount();
      for(%j = 0; %j < %count; %j++)
      {
         %brick = %group.getObject(%j);

         //we're only interested in bricks...
         if(!(%brick.getType() & $TypeMasks::FxBrickAlwaysObjectType))
            continue;

         //that are on the ground...
         if(%brick.getDistanceFromGround() != 0)
            continue;

         //and planted...
         if(!%brick.isPlanted)
            continue;
         
         //and not dead...
         if(%brick.isDead)
            continue;

         %brickData = %brick.getDataBlock().getID();
         if(%brickData.category $= "Baseplates")
         {
            //it's a baseplate, but if it's all alone and red or has an item attached to it, it's probably still spam
            if(%brick.getNumUpBricks() == 0 && (%brick.getColorID() == 0 || isObject(%brick.item)) )
            {
               %brick.killBrick();
            }
            //if this is a red "plain" or "road" baseplate with an identical baseplate on top of it, it's probably spam
            else if(%brick.getNumUpBricks() == 1 && %brick.getColorID() == 0 && (%brickData.subCategory $= "Plain" || %brickData.subCategory $= "Road"))
            {
               %upBrick = %brick.getUpBrick(0);
               if(%upBrick.getDataBlock().getID() == %brickData && %upBrick.getColorID() == 0)
                  %brick.killBrick();
            }
         }
         else
         {
            //not a baseplate, kill it
            %brick.killBrick();
         }
      }
   }
}

function serverCmdClearFloatingBricks(%client)
{
   if(!%client.isAdmin)
      return;
   
   if($Server::BrickCount > 0)
		messageAll('MsgClearBricks', "\c3" @ %client.getPlayerName() @ "\c0 cleared floating bricks.");

   //loop through all bricks
   %groupCount = MainBrickGroup.getCount();
   for(%i = 0; %i < %groupCount; %i++)
   {
      %group = MainBrickGroup.getObject(%i);
      %count = %group.getCount();
      for(%j = 0; %j < %count; %j++)
      {
         %brick = %group.getObject(%j);
         if(!(%brick.getType() & $TypeMasks::FxBrickAlwaysObjectType))
            continue;

         if(%brick.getDistanceFromGround() != 2147483647)
            continue;

         if(!%brick.isPlanted)
            continue;
         
         if(%brick.isDead)
            continue;

         %brick.killBrick();
      }
   }
}


//clears bricks that are > 1000 units away
function serverCmdClearFarAwayBricks(%client)
{
   if(!%client.isAdmin)
      return;

   %player = %client.player;

   if(!isObject(%player))
      return;

   if($Server::BrickCount <= 0)
      return;

   messageAll('MsgClearBricks', "\c3" @ %client.getPlayerName() @ "\c0 cleared far away bricks.");

   %playerPos = %player.getPosition();

   //loop through all bricks
   %groupCount = MainBrickGroup.getCount();
   for(%i = 0; %i < %groupCount; %i++)
   {
      %group = MainBrickGroup.getObject(%i);
      %count = %group.getCount();
      for(%j = 0; %j < %count; %j++)
      {
         %brick = %group.getObject(%j);
         if(!(%brick.getType() & $TypeMasks::FxBrickAlwaysObjectType))
            continue;

         if(%brick.getDistanceFromGround() != 0)
            continue;

         if(!%brick.isPlanted)
            continue;
         
         if(%brick.isDead)
            continue;

         %brickPos = %brick.getPosition();

         %delta = vectorSub(%brickPos, %playerPos);
         %distance = vectorLen(%delta);

         if(%distance < 1000)
            continue;

         %brick.killBrick();
      }
   }
}

function scheduletest()
{
   if(isEventPending($ST))
   {
      cancel($ST);
      return;
   }
   
   echo("time delta: "@ getSimTime() - $STTime);
   $STTime = getSimTime();

   $ST = schedule(33,0, scheduleTest);

}