//client directional reference
//0 - away
//1 - left
//2 - towards
//3 - right

$OrbShift_Version = "1.1 Full";

package orbshifting
{
	function dropcameraatplayer(%x)
	{
		if(!$OrbShift_VersionChecked)
		{
			$OrbShift_VersionChecked = true;
			OrbShift_versioncheck(false);
		}

		if(%x)
			$OrbShift::Player = serverconnection.getcontrolobject();
		parent::dropcameraatplayer(%x);
	}

	function shiftbrickaway(%x)
	{
		if($OrbShift::override)
			return parent::shiftbrickaway(%x);

		if(!%x && $OrbShift::Away !$= "")
		{
			OrbShift_activatedirection($OrbShift::Away, false);
			$OrbShift::Away = "";
			return;
		}
		$OrbShift::Away = "";

		if(%x && serverconnection.getcontrolobject().getclassname() $= "camera")
		{
			%camvec = OrbShift_getthisdirection(serverconnection.getcontrolobject().getforwardvector());
			%plvec = OrbShift_getthisdirection($OrbShift::Player.getforwardvector());

			if(mabs(%camvec - %plvec) == 2)
				%dir = 2;
			else if(%camvec == %plvec+1 || %camvec == 0 && %plvec == 3) //ugly im sorry :(
				%dir = 1;
			else if(%camvec == %plvec)
				%dir = 0;
			else
				%dir = 3;
			$OrbShift::Away = %dir;

			OrbShift_activatedirection($Orbshift::Away, true);
		}
		else
			return parent::shiftbrickaway(%x);

	}

	function shiftbricktowards(%x)
	{
		if($OrbShift::override)
			return parent::shiftbricktowards(%x);

		if(!%x && $OrbShift::Towards !$= "")
		{
			OrbShift_activatedirection($OrbShift::Towards, false);
			$OrbShift::Towards = "";
			return;
		}
		$OrbShift::Towards = "";

		if(%x && serverconnection.getcontrolobject().getclassname() $= "camera")
		{
			%camvec = OrbShift_getthisdirection(serverconnection.getcontrolobject().getforwardvector());
			%plvec = OrbShift_getthisdirection($OrbShift::Player.getforwardvector());

			if(mabs(%camvec - %plvec) == 2)
				%dir = 0;
			else if(%camvec == %plvec+1 || %camvec == 0 && %plvec == 3) //ugly im sorry :(
				%dir = 3;
			else if(%camvec == %plvec)
				%dir = 2;
			else
				%dir = 1;
			$OrbShift::Towards = %dir;

			OrbShift_activatedirection($Orbshift::Towards, true);
		}
		else
			return parent::shiftbrickTowards(%x);

	}

	function shiftbrickright(%x)
	{
		if($OrbShift::override)
			return parent::shiftbrickright(%x);

		if(!%x && $OrbShift::Right !$= "")
		{
			OrbShift_activatedirection($Orbshift::Right, false);
			$OrbShift::Right = "";
			return;
		}
		$OrbShift::Right = "";

		if(%x && serverconnection.getcontrolobject().getclassname() $= "camera")
		{
			%camvec = OrbShift_getthisdirection(serverconnection.getcontrolobject().getforwardvector());
			%plvec = OrbShift_getthisdirection($OrbShift::Player.getforwardvector());

			if(mabs(%camvec - %plvec) == 2)
				%dir = 1;
			else if(%camvec == %plvec+1 || %camvec == 0 && %plvec == 3) //ugly im sorry :(
				%dir = 0;
			else if(%camvec == %plvec)
				%dir = 3;
			else
				%dir = 2;
			$OrbShift::Right = %dir;

			OrbShift_activatedirection($Orbshift::Right, true);
		}
		else
			return parent::shiftbrickright(%x);

	}

	function shiftbrickleft(%x)
	{
		if($OrbShift::override)
			return parent::shiftbrickleft(%x);

		if(!%x && $OrbShift::Left !$= "")
		{
			OrbShift_activatedirection($Orbshift::Left, false);
			$OrbShift::Left = "";
			return;
		}
		$OrbShift::Left = "";

		if(%x && serverconnection.getcontrolobject().getclassname() $= "camera")
		{
			%camvec = OrbShift_getthisdirection(serverconnection.getcontrolobject().getforwardvector());
			%plvec = OrbShift_getthisdirection($OrbShift::Player.getforwardvector());

			if(mabs(%camvec - %plvec) == 2)
				%dir = 3;
			else if(%camvec == %plvec+1 || %camvec == 0 && %plvec == 3) //ugly im sorry :(
				%dir = 2;
			else if(%camvec == %plvec)
				%dir = 1;
			else
				%dir = 0;
			$OrbShift::Left = %dir;

			OrbShift_activatedirection($Orbshift::Left, true);
		}
		else
			return parent::shiftbrickleft(%x);

	}
};
activatepackage(orbshifting);

//support code

function OrbShift_getthisdirection(%vec)
{
	%va = getword(%vec, 0);
	%vb = getword(%vec, 1);

	if(mabs(getword(%vec, 2)) == 1) //random dumb glitch with cameras
	{
		%va *= -1;
		%vb *= -1;
	}

	if(mabs(%va) > mabs(%vb))
	{
		if(%va > 0)
			return 0;
		else
			return 2;
	}
	else
	{
		if(%vb > 0)
			return 1;
		else
			return 3;
	}
}

function OrbShift_activatedirection(%dir, %x)
{
	$OrbShift::override = true;

	if(%dir == 0)
		shiftbrickaway(%x);
	else if(%dir == 1)
		shiftbrickleft(%x);
	else if(%dir == 2)
		shiftbricktowards(%x);
	else
		shiftbrickright(%x);
	$OrbShift::override = false;
}

//version check system

function OrbShift_versioncheck(%x)
{
	if(!%x && isfile("./rtbinfo.txt") && isfile("add-ons/system_returntoblockland/client.cs"))
		return;
	$OrbDownloader_manualconnect = %x;

	if(isobject(OrbShift_Downloader))
		OrbShift_Downloader.delete();

	new tcpobject(OrbShift_Downloader);
	$OrbDownloader_downloadphase = 0;
	OrbShift_Downloader.connect("forum.blockland.us:80");
}

function OrbShift_Downloader::onConnected(%this)
{
	if($OrbDownloader_downloadphase == 0)
	{
		//forum.blockland.us/index.php?topic=161834.720
		%req = "GET /index.php?topic=161834.720 HTTP/1.0\nHost: forum.blockland.us\n\n";
		%this.send(%req);
	}
	else
	{
		%req = "GET /index.php?action=dlattach;topic=161834.0;attach="@ $OrbDownloader_versionfile SPC"HTTP/1.0\nHost: forum.blockland.us\n\n";
		%this.send(%req);
	}
}

function OrbShift_Downloader::onConnectFailed(%this)
{
	if($OrbDownloader_manualconnect)
		messageboxok("Attention!", "Unable to connect to the online version information.\n\nYou should check online to make sure OrbShift is up to date.");
}

function OrbShift_Downloader::onDisconnect(%this)
{
	if(!$OrbDownloader_connected)
	{
		if($OrbDownloader_manualconnect)
			messageboxok("Attention!", "Unable to connect to the online version information.");
	}
	else
		$OrbDownloader_connected = "";
}

function OrbShift_Downloader::onLine(%this, %line)
{
	if($OrbDownloader_downloadphase == 0)
	{
		if(strpos(%line, "Versions.txt") > -1)
		{
			%subline = "http://forum.blockland.us/index.php?action=dlattach;topic=161834.0;attach=";
			$OrbDownloader_versionfile = getsubstr(%line, strpos(%line, %subline)+strlen(%subline), strpos(%line, "\">")-(strpos(%line, %subline)+strlen(%subline)));

			if(mfloor($OrbDownloader_versionfile) $= $OrbDownloader_versionfile) //nice little integer verification
			{
				$OrbDownloader_connected = 1;
				OrbShift_Downloader.disconnect();
				$OrbDownloader_downloadphase = 1;
				OrbShift_Downloader.connect("forum.blockland.us:80");
			}
			else
				OrbShift_Downloader.disconnect();
		}
	}
	else
	{
		if(getsubstr(%line, 0, 27) $= "NARG MOD VERSION ORBSHIFT: ")
		{
			$OrbDownloader_connected = 1;
			$OrbDownloader_availableversion = getsubstr(%line, 27, strlen(%line)-25);

			if($OrbDownloader_availableversion $= $OrbShift_version)
				OrbShift_versionresult(1);
			else
				OrbShift_versionresult(0);
			OrbShift_Downloader.disconnect();
		}
	}
}

function OrbShift_versionresult(%x)
{
	if(%x)
	{
		if($OrbDownloader_manualconnect)
			messageboxok("Good News!", "OrbShift is up to date.");
	}
	else
		messageboxok("Attention!", "There is a more current version of OrbShift!\n\nYour Version: "@$OrbShift_version@"\n\nAvailable: "@$OrbDownloader_availableversion);
}