// Blockland - tutorial.cs
// Copyright (c) 2007 Step 1: Games LLC
// 
// special stuff for the tutorial level

//-----------------------------------
// required add-ons
//-----------------------------------
function tutorial_LoadRequiredAddOns()
{
   %addon1 = ForceRequiredAddon("Vehicle_Jeep");
   %addon2 = ForceRequiredAddon("Vehicle_Horse");
   %addon3 = ForceRequiredAddon("Weapon_Gun");
   %addon4 = ForceRequiredAddon("Particle_FX Cans");
   %addon5 = ForceRequiredAddon("Print_Letters_Default");
   %addon6 = ForceRequiredAddon("Projectile_Radio Wave");
   for(%i=1;%i<7;%i++)
   {
      if(%addon[%i] == $Error::AddOn_NotFound)
      {
      MessageBoxYesNo("Ooops","The Tutorial needs to enable some of the default Blockland Add-ons but they appear to be missing.\n\nYou cannot complete the tutorial without them. Would you like to quit?","disconnect();","");
      break;
      }
   }
}
tutorial_LoadRequiredAddOns();
loadPrintedBrickTextures();

//-----------------------------------
// gui
//-----------------------------------
if(!isObject(tutorialCompletedGui))
   exec("Add-Ons/Map_Tutorial/tutorialCompletedGui.gui");

//-----------------------------------
// win trigger
//  for detecting when you've completed an obstacle
//-----------------------------------
datablock TriggerData(TutorialWinTrigger)
{
   tickPeriodMS = 100;
};

function TutorialWinTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);
   
   if(isObject(%obj.getMountedObject(0).client))
   {
      %obj = %obj.getMountedObject(0);
   }

   if($TutorialCompleted && %trigger.goalName !$= "Secrets")
      return;
   
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;
   if(%obj.goalCompleted[%trigger.goalName] == true)
      return;
      
   //hacks for enabling player abilities
   switch$(%trigger.goalName)
   {
      case "Diving":
         %obj.setDataBlock(PlayerTutorialNoJet);   
      case "Ride":
         electricWater.setEmitterDataBlock(0);
   }

   if(%trigger.goalName $= "Light")
   {
      if(isObject(%client.player.light))
         serverCmdLight(%client);
   }

   %obj.goalCompleted[%trigger.goalName] = true;

   %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
   
   %obj.emote(winStarProjectile, 1); //1 = skip spam protection
   %client.play2D(rewardSound);
   $Tutorial::GoalsCompleted++;
   CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - " @ %trigger.goalName @ " - Time: " @ %time, 3);
   CommandToClient(%client, 'CenterPrint', "", 0);
}

function TutorialWinTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialWinTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
}

//-----------------------------------
// generic tip trigger
//  simple "press x to <verb>" tips
//-----------------------------------
datablock TriggerData(TutorialTipTrigger)
{
   tickPeriodMS = 100;
};

function TutorialTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);

   if($TutorialCompleted)
      return;

   //%this.giveTip(%trigger, %obj);      
}

function TutorialTipTrigger::GiveTip(%this, %trigger, %obj)
{  
   %obj.lastTipTime = getSimTime();
   
   %client = %obj.client;

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to " @ %trigger.taskName , 2);
}

function TutorialTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);

   if(%obj.goalCompleted[%trigger.goalName] == true || $TutorialCompleted)
      return;

   switch$(%trigger.goalName)
   {
      case "Diving":
         %obj.setDataBlock(PlayerTutorialNoJet);   
   }
}

function TutorialTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);

   if($TutorialCompleted)
      return;

   if(isObject(%obj.getMountedObject(0).client))
   {
      %obj = %obj.getMountedObject(0);
   }
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   if(%obj.getDamageLevel() >= 1.0)
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   switch$(%trigger.goalName)
   {
      case "Jet":
         %obj.setDataBlock(PlayerStandardArmor);          
      case "Light":
         %obj.setDataBlock(PlayerTutorialNoJet);
   }

   if(%obj.goalCompleted[%trigger.goalName] == true)
      return;

   //hacks for enabling player abilities
   switch$(%trigger.goalName)
   {
      case "Jump":
         %obj.setDataBlock(PlayerTutorialNoJet);   
      case "Light":
         if(!$TutorialPart1Completed)
         {
            $TutorialPart1Completed = true;
            clientgroup.getobject(0).brickGroup.deleteAll();
            serverDirectSaveFileLoad("Add-Ons/Map_Tutorial/Tutorial_Part2.bls", 3, "", 0, 1); //serverDirectSaveFileLoad(filename, colormethod, directory name, do ownership, silent)
         }

         if(!$LoadingBricks_Client)
         {
            //add restrictions to the vehicle pads
            _TutorialVehicleBrick1.vehicleLimit = "HorseArmor";
            _TutorialVehicleBrick2.vehicleLimit = "JeepVehicle";

            //prevent breaking of certain key bricks
            _TutorialVehicleBrick1.noBreak    = true;
            _TutorialVehicleBrick2.noBreak    = true;

            _TutorialWrenchBrick.noBreak      = true;
            
            _TutorialWrenchSpawnBrick.noBreak  = true;
            _TutorialPrinterSpawnBrick.noBreak = true;
            _TutorialGunSpawnBrick.noBreak     = true;

            _TutorialPrintBrick1.noBreak = true;
            _TutorialPrintBrick2.noBreak = true;
            _TutorialPrintBrick3.noBreak = true;
            _TutorialPrintBrick4.noBreak = true;
            _TutorialPrintBrick5.noBreak = true;
            _TutorialPrintBrick6.noBreak = true;
            _TutorialPrintBrick7.noBreak = true;

            _TutorialDoor2.noBreak = true;
            _TutorialDoor3.noBreak = true;
            _TutorialDoor4.noBreak = true;
            _TutorialDoor5.noBreak = true;
            _TutorialDoor6.noBreak = true;
         }

         if(isObject(%client.player.light))
         {
            %obj.lastTipTime = 0;
            commandToClient(%client, 'centerPrint');
            return;
         }
      case "Dismount":
         if(!isObject(%client.player.getObjectMount()))
         {
            %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);

            %obj.emote(winStarProjectile, 1); //1 = skip spam protection
            %client.play2D(rewardSound);
            $Tutorial::GoalsCompleted++;
            CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Dismount - Time: " @ %time, 3);
            CommandToClient(%client, 'CenterPrint', "", 0);

            %obj.goalCompleted["Dismount"] = 1;
            return;
         }
      case "Diving":
         %obj.setDataBlock(PlayerStandardArmor);  
   }
   

   if( (getSimTime() - %obj.lastTipTime) > 2500 )
   {
      %this.giveTip(%trigger, %obj);
   }
}


//-----------------------------------
// Look tip trigger
//  Hackish thing to prompt you to look behind you and then move
//-----------------------------------

datablock TriggerData(TutorialLookTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialLookTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);

   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if($TutorialCompleted)
      return;

   if(!%obj.goalCompleted["Look"])
   {
      //stop player from moving 
      %obj.setDataBlock(PlayerTutorialNoMove);

      //clear inventory
      messageClient(%client, 'MsgClearInv');
      commandToClient(%client, 'PlayGui_CreateToolHud', %obj.getDataBlock().maxTools);
      for(%i = 0; %i < 5; %i++)
      {
         %obj.tool[%i] = 0;
      }
      %obj.weaponCount = 0;

      for(%i = 0; %i < 10; %i++)
      {
         %obj.client.inventory[%i] = 0;
      }

      stopTargetPractice();
      if(isObject(TutorialTargets))
         TutorialTargets.delete();

      //clear bricks and load the default save
      $TutorialPart1Completed = false;
      $Tutorial::GoalsCompleted = 0;
      $Tutorial::TotalTargetsHit = 0;
      $Tutorial::TotalTargetsLaunched = 0;
      clientgroup.getobject(0).brickGroup.deleteAll();
      serverDirectSaveFileLoad("Add-Ons/Map_Tutorial/Tutorial_Part1.bls", 3, "", 0, 1); //serverDirectSaveFileLoad(filename, colormethod, directory name, do ownership, silent)

      //reset electric water effect
      electricWater.setEmitterDataBlock(radioWaveExplosionEmitter);
      
      

//      //load special bricks so we can keep track of them
//      %b = tutorialPlaceBrick("_TutorialWrenchBrick","brick2x2x2ConeData","-38.5 -106 95.8",2,4);  //Wrenchy Brick
//      %b.canWrench = 1;
//      
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick1","brick1x4x4printData","-18.25 -103 95.6",1,4); //Print Brick 1 (O)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick2","brick1x4x4printData","-18.25 -105 95.6",1,4); //Print Brick 2 (I)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick3","brick1x4x4printData","-18.25 -107 95.6",1,4); //Print Brick 3 (N)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick4","brick1x4x4printData","-18.25 -109 95.6",1,4); //Print Brick 4 (K)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick5","brick1x4x4printData","-21.5 -111.75 95.6",2,4); //Print Brick 5 (M)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick6","brick1x4x4printData","-23.5 -111.75 95.6",2,4); //Print Brick 6 (0)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      %brick = tutorialPlaceBrick("_TutorialPrintBrick7","brick1x4x4printData","-25.5 -111.75 95.6",2,4); //Print Brick 7 (0)
//      %brick.setPrint($printNameTable["Letters/-minus"]);
//      
//      %b = tutorialPlaceBrick("_TutorialSprayBrick1","brick1x3Data","-87.25 -58.25 95.9",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick2","brick2x3Data","-86.5 -58.25 95.9",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick3","brick1x1Data","-86.75 -58.25 96.5",2,4);
//      %b.canSpray = 1;
//
//      %b = tutorialPlaceBrick("_TutorialSprayBrick4","brick2x3fData","-87 -61.25 95.7",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick5","brick1x3fData","-86.25 -61.25 95.7",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick6","brick1x1roundData","-86.75 -61.75 96.1",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick7","brick1x1roundData","-86.75 -61.25 96.1",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick8","brick1x1roundData","-86.75 -60.75 96.1",2,4);
//      %b.canSpray = 1;
//
//      %b = tutorialPlaceBrick("_TutorialSprayBrick9","brick2x2roundData","-87 -64 95.9",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick10","brick2x2x2ConeData","-87 -64 96.8",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick11","brick1x1roundData","-86.25 -64.25 95.9",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick12","brick1x1roundData","-86.25 -64.75 95.9",2,4);
//      %b.canSpray = 1;
//      %b = tutorialPlaceBrick("_TutorialSprayBrick13","brick1x1roundData","-86.75 -64.75 95.9",2,4);
//      %b.canSpray = 1;
//
//      %b = tutorialPlaceBrick("_TutorialVehicleBrick1","brickVehicleSpawnData","-5.5 -121 94.5",3,4);
//      %b.canWrench = 1;
//      %b.vehicleLimit = "HorseArmor";
//      %b = tutorialPlaceBrick("_TutorialVehicleBrick2","brickVehicleSpawnData","-53 -80.5 94.5",1,4);
//      %b.canWrench = 1;
//      %b.vehicleLimit = "JeepVehicle";
//      %b.setVehicle(JeepVehicle.getID());
//      %b.setReColorVehicle(1);
//
//      //Doors
//      %d = tutorialPlaceBrick("_TutorialDoor1","brick4x1x5WindowData","13.75 -91 95.9",1,4); //Bricks
//      %d = tutorialPlaceBrick("_TutorialDoor2","brick4x1x5WindowData","-31.25 -106 95.9",1,4); //Wrench
//      %d = tutorialPlaceBrick("_TutorialDoor3","brick4x1x5WindowData","-23.5 -98.75 95.9",0,4); //Print
//      %d = tutorialPlaceBrick("_TutorialDoor4","brick4x1x5WindowData","-45.75 -79 95.9",3,4); //Shoot
//      %d = tutorialPlaceBrick("_TutorialDoor5","brick4x1x5WindowData","-75.75 -61 95.9",3,4); //Drive
//      %d = tutorialPlaceBrick("_TutorialDoor6","brick4x1x5WindowData","-83.5 -68.25 95.9",2,4); //Spray
//
//      //Wand+Hammer Bricks
//      for(%i=0;%i<15;%i++)
//      {
//         %heightAdd = %i*0.6;
//         if(%i < 5)
//         {
//            %b = tutorialPlaceBrick("","brick2x4Data","-83.5 -83.5" SPC 94.7+%heightAdd,1,4);
//            %b.canHammer = 1;
//         }
//
//         if(%i < 7)
//         {
//            %b = tutorialPlaceBrick("","brick2x4Data","22.5 -112.5" SPC 94.7+%heightAdd,1,4);
//            %b.canHammer = 1;
//            %b = tutorialPlaceBrick("","brick2x4Data","20.5 -112.5" SPC 94.7+%heightAdd,1,4);
//            %b.canHammer = 1;
//         }
//
//         if(%i < 13)
//         {
//            %b = tutorialPlaceBrick("","brick2x4Data","-83.5 -81.5" SPC 94.7+%heightAdd,1,4);
//            %b.canHammer = 1;
//         }
//
//         %b = tutorialPlaceBrick("","brick2x4Data","-82.5 -82.5" SPC 94.7+%heightAdd,1,4);
//         %b.canHammer = 1;
//         %b = tutorialPlaceBrick("","brick2x4Data","-84.5 -82.5" SPC 94.7+%heightAdd,1,4);
//         %b.canHammer = 1;
//      }   
      
      $Tutorial::HorseExists = 0;
      $Tutorial::Horse = "";    

      //prompt them too look behind them
      %obj.lastTipTime = getSimTime();
      CommandToClient(%client, 'CenterPrint', "Move \c3the mouse\c0 to look around", 2);
   }  
   else if(!%obj.goalCompleted["Move"])
   {
      //tell them to how to move
      %obj.lastTipTime = getSimTime();
   }
   
}

function openTutorialDoor(%door)
{
   %door = "_TutorialDoor"@%door;
   if(isObject(%door))
   {
	%door.setRendering(0);
	%door.setRaycasting(0);
	%door.setColliding(0);
	%door.schedule(2000,"delete");
   }
}

function TutorialLookTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialLookTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
   
   if($TutorialCompleted)
      return;

   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if(!%obj.goalCompleted["Look"])
   {
      //check if they're looking the right direction
         //if they are, complete goal and let them move again
      %targetPos = TutorialLookTarget.getPosition();
      %playerPos = %obj.getPosition();
      %targetVec = vectorNormalize(vectorSub(%targetPos, %playerPos));
      %eyeVec = %obj.getEyeVector();

      %dot = vectorDot(%targetVec, %eyeVec);

      if(%dot > 0.65)
      {
         //reward
         %obj.goalCompleted["Look"] = true;
         %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
         %obj.emote(winStarProjectile, 1); //1 = skip spam protection
         %client.play2D(rewardSound);
         $Tutorial::GoalsCompleted++;
         CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Look - Time: " @ %time, 3);

         //allow movement
         %obj.setDataBlock(PlayerTutorialNoJumpNoJet);
         return;
      }

      //prompt them too look behind them
      if(getSimTime() - %obj.lastTipTime > 2500)
      {
         %obj.lastTipTime = getSimTime();
         CommandToClient(%client, 'CenterPrint', "Move \c3the mouse\c0 to look around", 2);
      }
   }  
   else if(!%obj.goalCompleted["Move"])
   {
      //tell them to how to move
      if(getSimTime() - %obj.lastTipTime > 2500)
      {
         %obj.lastTipTime = getSimTime();

         //need bind name, task name, goal name 
         %wkey = strUpr(getField(movemap.getBinding(moveforward), 1));
         %akey = strUpr(getField(movemap.getBinding(moveleft), 1));
         %skey = strUpr(getField(movemap.getBinding(movebackward), 1));         
         %dkey = strUpr(getField(movemap.getBinding(moveright), 1));

         CommandToClient(%client, 'CenterPrint', "Press \c3" @ %wkey SPC %akey SPC %skey SPC %dkey  @ "\c0 to move" , 2);
      }
   }

}

//-----------------------------------
// Brick tip trigger
//  Hackish thing to detect when you buy bricks
//-----------------------------------

datablock TriggerData(TutorialBrickTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialBrickTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialBrickTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialBrickTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
   
   if($TutorialCompleted)
      return;

   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if(%obj.goalCompleted["Brick"])
      return;

   if(%obj.getMountedImage(0) $= brickImage.getID())
   {
      %obj.goalCompleted["Brick"] = true;
	openTutorialDoor(1);

      %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
      
      %obj.emote(winStarProjectile, 1); //1 = skip spam protection
      %client.play2D(rewardSound);
      $Tutorial::GoalsCompleted++;
      CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Bricks - Time: " @ %time, 3);
      CommandToClient(%client, 'CenterPrint', "", 0);
      return;
   }

   //see if we have bricks
   %maxInv = %obj.getDataBlock().maxItems;
   for(%i = 0; %i < %maxInv; %i++)
   {
      if(isObject(%obj.client.inventory[%i]))
      {
         %obj.goalCompleted["Brick"] = true;
	   openTutorialDoor(1);

         %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
      
         %obj.emote(winStarProjectile, 1); //1 = skip spam protection
         %client.play2D(rewardSound);
         $Tutorial::GoalsCompleted++;
         CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Bricks - Time: " @ %time, 3);
         CommandToClient(%client, 'CenterPrint', "", 0);
         return;
      }
   }

   if(getSimTime() - %obj.lastTipTime < 2500)
      return;

   %obj.lastTipTime = getSimTime();

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to " @ %trigger.taskName , 2);

}

//-----------------------------------
// Build tip trigger
//  Hackish thing to detect when you're building
//-----------------------------------

datablock TriggerData(TutorialBuildTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialBuildTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialBuildTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   if(!$TutorialCompleted)
   {
      if(%obj.getMountedImage(0).item $= "sprayCan")
	   %obj.unmountImage(0);
   }
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialBuildTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
   
   if($TutorialCompleted)
      return;

   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if(%obj.goalCompleted["Build"])
      return;

   //need bind name, task name, goal name 
   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;

   if(isObject(%obj.tempBrick))
   {
      %sakey = bindNameFix("shiftBrickAway");
      %stkey = bindNameFix("shiftBrickTowards");
      %slkey = bindNameFix("shiftBrickLeft");
      %srkey = bindNameFix("shiftBrickRight");

      %sukey = bindNameFix("shiftBrickUp");
      %sdkey = bindNameFix("shiftBrickDown");
      %sutkey = bindNameFix("shiftBrickThirdUp");
      %sdtkey = bindNameFix("shiftBrickThirdDown");

      %plantkey = bindNameFix("plantBrick");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %sakey @"\c0,\c3 "@ %stkey @"\c0,\c3 "@ %slkey @" \c0or\c3 "@ %srkey @ "\c0 to move brick laterally\n" @
            "\c0Press \c3" @ %sukey @"\c0,\c3 "@ %sdkey  @"\c0,\c3 "@ %sutkey @ " \c0or\c3 " @ %sdtkey @ " \c0to move brick vertically\n\nPress \c3" @ %plantkey @ "\c0 to plant brick", 3);
   }
   else if(%image == BrickImage.getId())
   {
      %key = bindNameFix("mouseFire");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to create a ghost brick" , 2);
   }   
   else
   {
      %key = bindNameFix("useBricks");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip bricks" , 2);
   }

}


//-----------------------------------
// Break tip trigger
//  Hackish thing to detect when you have a hammer, have it out, etc
//-----------------------------------

datablock TriggerData(TutorialBreakTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialBreakTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialBreakTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialBreakTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
   
   if($TutorialCompleted)
      return;

   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;
   
   //to fix backtracking from jet room
   %obj.setDataBlock(PlayerTutorialNoJet);   
   
   if(%obj.goalCompleted["Break"])
      return;

   //need bind name, task name, goal name 
   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;

   if(%image == hammerImage.getID())
   {
      %key = bindNameFix("mouseFire");
      CommandToClient(%client, 'CenterPrint', "Aim at the bricks and press \c3" @ %key @ "\c0 to break them\n\nThe hammer can only break bricks on the top of the stack" , 2);
   }
   else if(isObject(%obj.tool[0]))
   {
      %key = bindNameFix("useTools");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip the hammer" , 2);
   }   
   else
   {
      CommandToClient(%client, 'CenterPrint', "Run over the hammer to pick it up" , 2);
   }

}



//-----------------------------------
// Ride tip trigger
//  Hackish thing to detect when you spawn a horse
//-----------------------------------

datablock TriggerData(TutorialRideTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialRideTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   if($TutorialCompleted)
      return;

   if(%obj.dataBlock $= "HorseArmor")
   {
      $Tutorial::HorseExists = 1;
      $Tutorial::Horse = %obj;
   }
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialRideTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   if($TutorialCompleted)
      return;

   if(%obj.dataBlock $= "HorseArmor")
      $Tutorial::HorseExists = 0;
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialRideTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
   
   if($TutorialCompleted)
      return;

   if(%obj.getClassName() $= "WheeledVehicle" || %obj.getClassName() $= "FlyingVehicle")
   {
      %obj.finalExplosion();      
      return;
   }   

   if(isObject(%obj.getMountedObject(0).client))
   {
      %client = %obj.getMountedObject(0).client;
      %obj = %client.player;
   }
   else
      %client = %obj.client;
      
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   if(!isObject(%client))
      return;

   if(%obj.goalCompleted["Ride"])
      return;

   //if(getSimTime() - %obj.lastTipTime < 500)
   //   return;

   %obj.lastTipTime = getSimTime();

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;
      
   for(%i=0;%i<%obj.dataBlock.maxTools;%i++)
   {
      if(%obj.tool[%i] == WrenchItem.getID())
      {
         %hasWrench = 1;
         break;
      }
   }

   if(isObject(%obj.getObjectMount()))
   {
      CommandToClient(%client, 'CenterPrint', "Control this like you would a Normal Player.\n\nNow jump across the gap to the next area of the Tutorial", 0.7);
   }
   else if($Tutorial::HorseExists)
   {
      %key = bindNameFix("Jump");
      CommandToClient(%client, 'CenterPrint', "Jump on top of the horse by pressing \c3"@%key, 0.7);
   }
   else if(%image == wrenchImage.getID())
   {
      %key = bindNameFix("mouseFire");
      CommandToClient(%client, 'CenterPrint', "Aim at the vehicle spawn and press \c3" @ %key @ "\c0 to add a vehicle\n\nSelect the horse" , 0.7);
   }
   else if(%hasWrench && (%image $= 0 || %image == BrickImage.getID()) )
   {
      %key = bindNameFix("useTools");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip the wrench" , 0.7);
   }   
   else if(%hasWrench && %image !$= wrenchImage.getID())
   {
      CommandToClient(%client, 'CenterPrint', "Use the \c3mouse wheel\c0 to scroll to the wrench" , 0.7);
   }   
   else
   {
      CommandToClient(%client, 'CenterPrint', "Run over the wrench to pick it up" , 0.7);
   }

}



//-----------------------------------
// Water trigger
//  Puts you at beginning of area if you jump in water
//-----------------------------------

datablock TriggerData(TutorialWaterTrigger)
{
   tickPeriodMS = 50;
};

function TutorialWaterTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   if($TutorialCompleted)
      return;

   if(%obj.goalCompleted["Ride"])
      return;
      
   if(isObject(%obj.client))
   {
      %obj.setTransform("-2.64172 -127.042 94.75 0 0 -1 0.881075");
      %obj.setDamageFlash(0.8);
      %obj.setVelocity("0 0 0.1");
   }
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialWaterTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialWaterTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
}




//-----------------------------------
// Secrets trigger
//  Tip trigger
//-----------------------------------

datablock TriggerData(TutorialSecretTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialSecretTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialSecretTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialSecretTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if(%obj.goalCompleted["Secrets"])
      return;
      
   if(getSimTime() - %obj.lastTipTime < 300)
      return;
      
   %obj.lastTipTime = getSimTime();
      
   centerPrint(%obj.client,"Many of the maps included in Blockland contain \n\c3secret passages\c0 and \c3hidden spaces\c0 to build.\n\nTry finding some of them with your \c3friends\c0 later on",2);
   Parent::onTickTrigger(%this,%trigger);
}



//-----------------------------------
// Wrench tip trigger
//  Hackish thing to detect when you set emitters/items/lights
//-----------------------------------

datablock TriggerData(TutorialWrenchTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialWrenchTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialWrenchTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialWrenchTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
      
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if($TutorialCompleted)
      return;

   if(%obj.goalCompleted["Wrench"])
      return;

   //if(getSimTime() - %obj.lastTipTime < 300)
   //   return;

   %obj.lastTipTime = getSimTime();

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;
      
   for(%i=0;%i<%obj.dataBlock.maxTools;%i++)
   {
      if(%obj.tool[%i] == WrenchItem.getID())
      {
         %hasWrench = 1;
         break;
      }
   }
   
   if(getSimTime() - %obj.wrenchDelayTime < 0)
      return;

   %theBrick = _TutorialWrenchBrick;
   if( (%image $= 0 || %image == BrickImage.getID()) && %hasWrench)
   {
      %key = bindNameFix("useTools");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip the Wrench" ,0.5);
   }
   else if(%image !$= WrenchImage.getID() && %hasWrench)
   {
	   CommandToClient(%client, 'CenterPrint', "Use the \c3mouse wheel\c0 to scroll to the Wrench" ,0.5);
   }
   else if(!%hasWrench)
   {
      CommandToClient(%client, 'CenterPrint', "You need to backtrack to find a Wrench to Continue" , 0.5);
   }
   else if(!%obj.subgoalCompleted["WrenchA"])
   {
      if(!isObject(%theBrick.light))
      {
         CommandToClient(%client, 'CenterPrint', "Click on the cone brick.\nApply a \c3Light\c0 to it and press Send" , 3);	
      }
      else
      {
         %obj.wrenchDelayTime = getSimTime() + 2000;
         %obj.subgoalCompleted["WrenchA"] = 1;
         CommandToClient(%client, 'CenterPrint', "\c2Well Done!" , 4);
      }
   }
   else if(!%obj.subgoalCompleted["WrenchB"])
   {
      if(isObject(%theBrick.light))
         %theBrick.setLight(0);

	   if(!isObject(%theBrick.emitter))
      {
	      CommandToClient(%client, 'CenterPrint', "Ok, now hit the cone brick again but this time\nApply an \c3Emitter\c0" , 3);
      }
	   else
	   {
         %obj.wrenchDelayTime = getSimTime() + 2000;
         %obj.subgoalCompleted["WrenchB"] = 1;
         CommandToClient(%client, 'CenterPrint', "\c2Nice One!" , 4);
	   }
   }
   else if(!%obj.subgoalCompleted["WrenchC"])
   {
      if(isObject(%theBrick.emitter))
         %theBrick.setEmitter(0);

      if(!isObject(%theBrick.item))
      {
         CommandToClient(%client, 'CenterPrint', "Finally, Hit the cone brick again but this time\nApply an \c3Item\c0" , 3);
      }
      else
      {
         %obj.subgoalCompleted["WrenchC"] = 1;
         CommandToClient(%client, 'CenterPrint', "\c2Good work!" , 3);
      }
   }
   else
   {
      //if(isObject(%theBrick.light))
      //   %theBrick.setLight(0);
      //if(isObject(%theBrick.item))
      //   %theBrick.setItem(0);
      %theBrick.setEmitter(rainbowPaintEmitter);

      openTutorialDoor(2);
      %obj.goalCompleted["Wrench"] = true;
      %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
      
      %obj.emote(winStarProjectile, 1); //1 = skip spam protection
      %client.play2D(rewardSound);
      $Tutorial::GoalsCompleted++;
      CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Wrench - Time: " @ %time, 3);
      //CommandToClient(%client, 'CenterPrint', "", 0);
   }
}



//-----------------------------------
// Print tip trigger
//  Hackish thing to detect when you change a print
//-----------------------------------

datablock TriggerData(TutorialPrintTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialPrintTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{      
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialPrintTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialPrintTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
      
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if($TutorialCompleted)
      return;

   if(%obj.goalCompleted["Print"])
      return;

   if(getSimTime() - %obj.lastTipTime < 300)
      return;

   %obj.lastTipTime = getSimTime();

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;
      
   %completedAllBricks = 1;
   %brickPrint1 = $printNameTable["Letters/O"];
   %brickPrint2 = $printNameTable["Letters/I"];
   %brickPrint3 = $printNameTable["Letters/N"];
   %brickPrint4 = $printNameTable["Letters/K"];
   %brickPrint5 = $printNameTable["Letters/M"];
   %brickPrint6 = $printNameTable["Letters/O"];
   %brickPrint7 = $printNameTable["Letters/O"];
   for(%i=1;%i<8;%i++)
   {
      %object = _TutorialPrintBrick@%i;
      if(isObject(%object))
      {
         if(%object.getPrintID() $= %brickPrint[%i])
            %object.setColor(2);
         else if(%object.getPrintID() $= $printNameTable["Letters/-minus"])
         {
            %object.setColor(4);
            %completedAllBricks = 0;
         }
         else
         {
            %object.setColor(0);
            %completedAllBricks = 0;
         }
      }
   }
      
   for(%i=0;%i<%obj.dataBlock.maxTools;%i++)
   {
      if(%obj.tool[%i] == PrintGun.getID())
      {
         %hasPrinter = 1;
         break;
      }
   }
   if( (%image $= 0 || %image == BrickImage.getID()) && %hasPrinter)
   {
      %key = bindNameFix("useTools");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip the printer" ,0.5);
      return;
   }
   else if(%image !$= PrintGunImage.getID() && %hasPrinter)
   {
      %key = bindNameFix("useTools");
      CommandToClient(%client, 'CenterPrint', "Use the \c3mouse wheel\c0 to scroll to the printer" ,0.5);
      return;
   }
   else if(!%hasPrinter)
   {
      CommandToClient(%client, 'CenterPrint', "You need to find a Printer to Continue" , 0.5);
      return;
   }
   else if(!%completedAllBricks)
   {
      CommandToClient(%client, 'CenterPrint', "Shoot a Printable Brick to set its Print\nYou can press the letter or number on your keyboard instead of selecting it\n\n<color:FFFFFF>Complete the Puzzle!" , 0.5);
   }
   else
   {
	openTutorialDoor(3);
      %obj.goalCompleted["Print"] = true;
      %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
      
      %obj.emote(winStarProjectile, 1); //1 = skip spam protection
      %client.play2D(rewardSound);
      $Tutorial::GoalsCompleted++;
      CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Print - Time: " @ %time, 3);
      CommandToClient(%client, 'CenterPrint', "", 0);
   }
}


//-----------------------------------
// Target Trigger
//  Activates when conditions are met
//-----------------------------------

datablock TriggerData(TutorialTargetsTrigger)
{
   tickPeriodMS = 50;
};

function TutorialTargetsTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialTargetsTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialTargetsTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
      
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if($TutorialCompleted)
      return;

   if(%obj.goalCompleted["Targets"])
      return;
      
   if(getSimTime() - %obj.lastTipTime < 300)
      return;
   %obj.lastTipTime = getSimTime();

   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;
      
   for(%i=0;%i<%obj.dataBlock.maxTools;%i++)
   {
      if(%obj.tool[%i] == GunItem.getID())
      {
         %hasGun = 1;
         break;
      }
   }
   if((%image $= 0 || %image == BrickImage.getID()) && %hasGun)
   {
      %key = bindNameFix("useTools");
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip the Gun" ,0.5);
      return;
   }
   else if(%image !$= GunImage.getID() && %hasGun)
   {
      CommandToClient(%client, 'CenterPrint', "Use the \c3mouse wheel\c0 to scroll to the Gun" ,0.5);
      return;
   }
   else if(!%hasGun)
   {
      CommandToClient(%client, 'CenterPrint', "Run over the gun to pick it up" , 0.5);
      return;
   }
   else
   {
      %bind = bindNameFix("mouseFire");
      CommandToClient(%client, 'CenterPrint', "Prepare for Target Practice!\n\nAim at the targets and use "@%bind@" to fire" , 4);
      %client.play2d(AlarmSound);
      %trigger.targetSchedule = schedule(4000,0,"beginTargetPractice");
      %obj.goalCompleted["Targets"] = 1;
   }
}



//-----------------------------------
// Wand trigger
//  Tip trigger
//-----------------------------------

datablock TriggerData(TutorialWandTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialWandTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   %obj.canuseWand = 1;
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialWandTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   if(!$TutorialCompleted)
   {
      %obj.canuseWand = 0;
      if(%obj.getMountedImage(0).item $= "WandItem")
	   %obj.unmountImage(0);
   }
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialWandTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;
	
   if($TutorialCompleted)
      return;

   if(%obj.goalCompleted["Wand"])
      return;
      
   if(getSimTime() - %obj.lastTipTime < 300)
      return;
   %obj.lastTipTime = getSimTime();

   %key = bindNameFix("globalchat");
   if(%obj.getMountedImage(0) !$= WandImage.getID())
      centerPrint(%obj.client,"Open the chat box by pressing \c3"@%key@"\c0 and then type \c3/wand\c0 to equip the Wand.",2);
   else
      centerPrint(%obj.client,"Now use the wand to break the bricks. Unlike the hammer, the wand\ncan break bricks anywhere in a stack. \n\nHowever any bricks supported by it will also fall!",2);
   Parent::onTickTrigger(%this,%trigger);
}



//-----------------------------------
// Spraycan tip trigger
//  Hackish thing to detect when you spray bricks
//-----------------------------------

datablock TriggerData(TutorialSprayTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialSprayTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   %obj.canUseSpray = 1;
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialSprayTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   if(%obj.getMountedImage(0).item $= "sprayCan")
	%obj.unmountImage(0);
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialSprayTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
      
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if(%obj.goalCompleted["Spray"])
      return;

   if($TutorialCompleted)
      return;

   //if(getSimTime() - %obj.lastTipTime < 3000)
   //   return;

   %obj.lastTipTime = getSimTime();

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;
      
   %changedColors = 0;
   %changedColFX = 0;
   %changedShapeFX = 0;
   for(%i=1;%i<14;%i++)
   {
      %object = _TutorialSprayBrick@%i;
      if(isObject(%object))
      {
         if(%object.getColorID() !$= 4)
            %changedColors = 1;
         if(%object.getColorFXID() !$= 0)
            %changedColFX = 1;
         if(%object.getShapeFXID() !$= 0)
            %changedShapeFX = 1;
      }
   }
   
   %key = bindNameFix("useSprayCan");
   if(%image.item !$= "sprayCan")
   {
      CommandToClient(%client, 'CenterPrint', "Press \c3" @ %key @ "\c0 to equip your Spray Can\nPress \c3"@%key@"\c0 again to switch paint columns\n\nUse the \c3mouse wheel\c0 to move up and down" ,4);
      return;
   }   
   else if(!%changedColors)
   {
      CommandToClient(%client, 'CenterPrint', "Try spraying some of the bricks \c3different colors\c0\n\nPress \c3"@%key@"\c0 to switch paint columns\nUse the \c3mouse wheel\c0 to move up and down" , 4);
      return;
   }
   else if(!%changedColFX)
   {
      CommandToClient(%client, 'CenterPrint', "Now try giving some of the bricks an \c3FX paint\c0 like \c3swirl or glow\c0\n\nPress \c3"@%key@"\c0 to switch paint columns\nUse the \c3mouse wheel\c0 to move up and down" , 4);
      return;
   }
   else if(!%changedShapeFX)
   {
      CommandToClient(%client, 'CenterPrint', "Finally, Try making some of the bricks \c3Undulo\c0\n\nPress \c3"@%key@"\c0 to switch paint columns\nUse the \c3mouse wheel\c0 to move up and down" , 4);
      return;
   }
   else
   {
	openTutorialDoor(6);
      %obj.goalCompleted["Spray"] = true;
      %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
      
      %obj.emote(winStarProjectile, 1); //1 = skip spam protection
      %client.play2D(rewardSound);
      $Tutorial::GoalsCompleted++;
      CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Spray - Time: " @ %time, 3);
      CommandToClient(%client, 'CenterPrint', "", 0);
   }
}

//-----------------------------------
// Jeep checkpoint trigger
//  Hackish thing to detect when you drive a vehicle in the box
//-----------------------------------

datablock TriggerData(TutorialJeepCheckTrigger)
{
   tickPeriodMS = 50;
};

function TutorialJeepCheckTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialJeepCheckTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialJeepCheckTrigger::onTickTrigger(%this,%trigger)
{
   Parent::onTickTrigger(%this,%trigger);
}

//-----------------------------------
// Drive tip trigger
//  Hackish thing to detect when you drive a vehicle correctly
//-----------------------------------

datablock TriggerData(TutorialDriveTipTrigger)
{
   tickPeriodMS = 50;
};

function TutorialDriveTipTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);  
}

function TutorialDriveTipTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialDriveTipTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
      
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;

   if(%obj.goalCompleted["Drive"])
      return;

   if($TutorialCompleted)
      return;

   if(getSimTime() - %obj.lastTipTime < 1000)
      return;

   %obj.lastTipTime = getSimTime();

   //need bind name, task name, goal name 
   %key = bindNameFix(%trigger.bindName);

   %image = %obj.getMountedImage(0);
   if(isObject(%image))
      %image = %image.getID();
   else
      %image = 0;

   if(!isObject(_TutorialVehicleBrick2.vehicle) && isObject(_TutorialVehicleBrick2))
   {
	_TutorialVehicleBrick2.setVehicle(JeepVehicle.getID());
	_TutorialVehicleBrick2.spawnVehicle();
   }
   else if(_TutorialVehicleBrick2.vehicle.dataBlock.getID() !$= JeepVehicle.getID() && isObject(_TutorialVehicleBrick2))
   {
	_TutorialVehicleBrick2.setVehicle(JeepVehicle.getID());
	_TutorialVehicleBrick2.spawnVehicle();
   }
   else if( _TutorialVehicleBrick2.vehicle.getMountNodeObject(0) !$= %obj && isObject(_TutorialVehicleBrick2) && !isObjectInsideObject(_TutorialVehicleBrick2.vehicle,JeepParkTrigger))
   {
	%keybind = bindNameFix("Jump");
	centerPrint(%client,"Press \c3"@%keybind@"\c0 to jump into the Jeep",3,3);
   }
   else if(_TutorialVehicleBrick2.vehicle.getMountNodeObject(0) $= %obj && _TutorialVehicleBrick2.vehicle.lastDrivingClient !$= "" && !isObjectInsideObject(_TutorialVehicleBrick2.vehicle,JeepParkTrigger) && isObject(_TutorialVehicleBrick2))
   {
	if(vectorDist(_TutorialVehicleBrick2.getPosition(),_TutorialVehicleBrick2.vehicle.getPosition()) < 5)
	{
	   if($pref::Input::UseStrafeSteering)
	   {
		   %wkey = strUpr(getField(movemap.getBinding(moveforward), 1));
         %akey = strUpr(getField(movemap.getBinding(moveleft), 1));
         %skey = strUpr(getField(movemap.getBinding(movebackward), 1));         
         %dkey = strUpr(getField(movemap.getBinding(moveright), 1));
		   centerPrint(%client,"Drive the Jeep by using \c3"@%wkey SPC %akey SPC %skey SPC %dkey@"\n\c0Complete the course and park the jeep",5,3);
	   }
	   else
	   {
         %wkey = strUpr(getField(movemap.getBinding(moveforward), 1));
         %skey = strUpr(getField(movemap.getBinding(movebackward), 1));
         centerPrint(%client,"Accelerate the Jeep by using \c3"@%wkey@"\c0 and brake using \c3"@%skey@"\n\c0You can steer using the \c3mouse\c0Complete the course and park the jeep",5,3);
	   }
	}
	else
	   centerPrint(%client,"Complete the course and park the jeep",5,3);
   }
   else if(_TutorialVehicleBrick2.vehicle.getMountNodeObject(0) !$= %obj && !isObjectInsideObject(_TutorialVehicleBrick2.vehicle,JeepParkTrigger) && isObject(_TutorialVehicleBrick2) && isPositionInsideObject(_TutorialVehicleBrick2.vehicle.getPosition(),JeepParkTrigger))
   {
	centerPrint(%client,"Ooops - You'll have to do a better parking than that!",3,3);
   }
   else if(_TutorialVehicleBrick2.vehicle.getMountNodeObject(0) $= %obj && isObjectInsideObject(_TutorialVehicleBrick2.vehicle,JeepParkTrigger) && isObject(_TutorialVehicleBrick2))
   {
	%keybind = bindNameFix("Jet");
	centerPrint(%client,"You can now get out of the Jeep by pressing \c3"@%keybind,3,3);
   }
   else
   {
	openTutorialDoor(5);
      %obj.goalCompleted["Drive"] = true;
      %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
      
      %obj.emote(winStarProjectile, 1); //1 = skip spam protection
      %client.play2D(rewardSound);
      $Tutorial::GoalsCompleted++;
      CommandToClient(%client, 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Drive - Time: " @ %time, 3);
      CommandToClient(%client, 'CenterPrint', "", 0);
   }
}

function isObjectInsideObject(%obj1,%obj2)
{
   if(!isObject(%obj1) || !isObject(%obj2))
      return;
      
   %obj1WB = %obj1.getWorldBox();
   %obj1MinX = getWord(%obj1WB,0);
   %obj1MinY = getWord(%obj1WB,1);
   %obj1MinZ = getWord(%obj1WB,2);
   %obj1MaxX = getWord(%obj1WB,3);
   %obj1MaxY = getWord(%obj1WB,4);
   %obj1MaxZ = getWord(%obj1WB,5);
   %obj2WB = %obj2.getWorldBox();
   %obj2MinX = getWord(%obj2WB,0);
   %obj2MinY = getWord(%obj2WB,1);
   %obj2MinZ = getWord(%obj2WB,2);
   %obj2MaxX = getWord(%obj2WB,3);
   %obj2MaxY = getWord(%obj2WB,4);
   %obj2MaxZ = getWord(%obj2WB,5);
   if(%obj1MinX >= %obj2MinX && %obj1MaxX <= %obj2MaxX && %obj1MinY >= %obj2MinY && %obj1MaxY <= %obj2MaxY && %obj1MinZ >= %obj2MinZ && %obj1MaxZ <= %obj2MaxZ)
      return true;
   else
      return false;
}

function isPositionInsideObject(%pos,%obj1)
{
   %WB = %obj1.getWorldBox();
   %XMin = getWord(%WB,0);
   %YMin = getWord(%WB,1);
   %ZMin = getWord(%WB,2);
   %XMax = getWord(%WB,3);
   %YMax = getWord(%WB,4);
   %ZMax = getWord(%WB,5);
   %PosX = getWord(%pos,0);
   %PosY = getWord(%pos,1);
   %PosZ = getWord(%pos,2);
   if(%PosX > %XMin && %PosX < %XMax && %PosY > %YMin && %PosY < %YMax && %PosZ > %ZMin && %PosZ < %ZMax)
      return true;
   else
      return false;
}

//-----------------------------------
// full win trigger
//  for detecting when you complete the entire tutorial
//-----------------------------------
datablock TriggerData(TutorialFullWinTrigger)
{
   tickPeriodMS = 100;
};

function TutorialFullWinTrigger::onEnterTrigger(%this,%trigger,%obj)
{
   Parent::onEnterTrigger(%this,%trigger,%obj);
   
   if(!(%obj.getType() & $TypeMasks::PlayerObjectType))
      return;
   %client = %obj.client;
   if(!isObject(%client))
      return;
      
   if($TutorialCompleted)
      return;
      
   %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
   
   %obj.emote(winStarProjectile, 1); //1 = skip spam protection
   %client.play2D(rewardSound);
   clearBottomPrint(%client);
   clearCenterPrint(%client);

   //show our stats on the completed dialog
   %prefix = "<font:arial:18><just:right>";
   %time = getTimeString((getSimTime() - %obj.spawnTime) / 1000);
   TutorialCompletedGui_Time.setText(%prefix @ %time);
   TutorialCompletedGui_Rooms.setText(%prefix @ $Tutorial::GoalsCompleted @ "/18");
   TutorialCompletedGui_Targets.setText(%prefix @ $Tutorial::TotalTargetsHit@ "/" @ $Tutorial::TotalTargetsLaunched);
   %percent = mCeil(($Tutorial::TotalTargetsHit/$Tutorial::TotalShotsFired)*100);
   TutorialCompletedGui_Accuracy.setText(%prefix @  %percent @ "%");

   canvas.pushdialog(tutorialCompletedGui);
   

   %client.player.setDataBlock(PlayerStandardArmor);

   %client.player.goalCompleted["Wand"] = 1;

   //Var to enable special hat or something?
   $Pref::Player::TutorialCompleted = 1;
}

function stayAndBuild()
{
   $TutorialCompleted = 1;

   //if this is demo mode then we barely have any bricks left so we should clear and load a minimal save
   if(!isUnlocked())
   {
      clientgroup.getobject(0).brickGroup.deleteAll();
      serverDirectSaveFileLoad("Add-Ons/Map_Tutorial/Tutorial_End.bls", 3, "", 0, 1); //serverDirectSaveFileLoad(filename, colormethod, directory name, do ownership, silent)
   }

   TutorialSpawn.setTransform("-83.3524 -91.2663 95.958 0 0 1 0");
   TutorialSpawn.radius = 5;
}

function TutorialFullWinTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function TutorialFullWinTrigger::onTickTrigger(%this,%trigger, %obj)
{  
   Parent::onTickTrigger(%this,%trigger);
}



//get bind names
function bindNameFix(%bindName)
{
   %device = getField(movemap.getBinding(%bindName), 0);
   %device = getSubStr(%device, 0, 5);
   %key = getField(movemap.getBinding(%bindName), 1);

   if(%device $= "mouse")
   {
      switch$(%key)
      {
         case "button0":
            %key = "left mouse button";
         case "button1":
            %key = "right mouse button";
         case "button2":
            %key = "middle mouse button";
         default:
            %key = "mouse " @ %key;
      }
   }
   else
   {
      switch$(%key)
      {
         case "space":
            %key = "spacebar";
         case "lshift":
            %key = "left shift";
         case "rshift":
            %key = "right shift";
         case "lalt":
            %key = "left alt";
         case "raltt":
            %key = "right alt";
      }
      
      if(strlen(%key) == 1)
         %key = strUpr(%key);
   }

   return %key;
}


//player datablocks to disable jets and jumping and such
datablock PlayerData(PlayerTutorialNoMove : PlayerStandardArmor)
{  
   airControl = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	showEnergyBar = false;
   jumpForce = 0;
   runforce = 0;
};

datablock PlayerData(PlayerTutorialNoJumpNoJet: PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	showEnergyBar = false;
   jumpForce = 0;
};

datablock PlayerData(PlayerTutorialNoJet : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	showEnergyBar = false;
};

datablock PlayerData(PlayerTutorialTarget : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

   maxForwardSpeed = 5;

	uiName = "";
	showEnergyBar = false;
};

//-----------------------------------
// Target Shooting
//  Reads targetSetup.txt - Syntax:
//    first number = row (1-3)
//    second number = speed (1-5)
//    timeout: x = time between each target launch = x
//    line break: 1000ms timeout
//-----------------------------------

datablock StaticShapeData(TutorialTarget)
{
	shapeFile = "./target.dts";
};
datablock StaticShapeData(TutorialTargetHit)
{
	shapeFile = "./targetHit.dts";
};
datablock StaticShapeData(TutorialTargetM)
{
	shapeFile = "./targetM.dts";
};
datablock StaticShapeData(TutorialTargetMHit)
{
	shapeFile = "./targetMHit.dts";
};

function tutorialPlaceBrick(%name,%type,%position,%rotation,%color)
{
   switch(%rotation)
   {
      case 0:
         %angularRotation = "1 0 0 0";
      case 1:
         %angularRotation = "0 0 1" SPC $piOver2;
      case 2:
         %angularRotation = "0 0 1" SPC $pi;
      case 3:
         %angularRotation = "0 0 -1" SPC $piOver2;
   }
   
   %brick = new fxDTSBrick(%name)
   {
      dataBlock = %type;
      position = %position;
      angleID = %rotation;
      colorID = %color;
      isPlanted = true;
      isBaseplate = true;
      
      colorFXID = "";
      shapeFXID = "";
      printID = "";
   };
   %brick.setTransform(%position SPC %angularRotation);
   %brick.setTrusted(1);
   %brick.plant();
   
   clientgroup.getobject(0).brickGroup.add(%brick);
   return %brick;
}

function beginTargetPractice()
{
   %file = new FileObject();
   if(%file.openForRead("Add-Ons/Map_Tutorial/targetSetup.txt"))
   {
      $Tutorial::TargetFile = %file;
      $Tutorial::ScheduleTime = 1000;
      $Tutorial::TotalTargetsLaunched = 0;
      $Tutorial::TotalTargetsHit = 0;
      $Tutorial::TotalShotsFired = 0;
      readTargetLine();
   }
   else
   {
      error("TUTORIAL ERROR: Target File not Found.");
      %file.close();
      %file.delete();
   }
}

function readTargetLine()
{
   %file = $Tutorial::TargetFile;
   if(!isObject(%file))
      return;
   if(%file.isEOF())
   {
      stopTargetPractice(1);
      return;
   }
   %line = %file.readLine();
   if(%line $= "")
      $Tutorial::TargetSchedule = schedule(1000,0,"readTargetLine");
   else
   {
      %targetRow = getWord(%line,0);
      %targetSpeed = getWord(%line,1);
	%targetType = getWord(%line,2);
      
      if(%targetRow $= "timeout:")
      {
         $Tutorial::ScheduleTime = %targetSpeed;
         $Tutorial::TargetSchedule = schedule($Tutorial::ScheduleTime,0,"readTargetLine");
         return;
      }
      
      launchTarget(%targetRow,%targetSpeed,%targetType);
         
      $Tutorial::TotalTargetsLaunched++;
      $Tutorial::TargetSchedule = schedule($Tutorial::ScheduleTime,0,"readTargetLine");
   }
}

function stopTargetPractice(%finish)
{
   if(%finish)
      checkForEnd();
      
   cancel($Tutorial::TargetSchedule);
   if(isObject($Tutorial::TargetFile))
      $Tutorial::TargetFile.delete();
}

function checkForEnd()
{
   if(TutorialTargets.getCount() $= 0)
   {
      %percent = mCeil(($Tutorial::TotalTargetsHit/$Tutorial::TotalShotsFired)*100);
      
      %time = getTimeString((getSimTime() - clientgroup.getobject(0).player.spawnTime) / 1000);
      
      clientgroup.getobject(0).player.emote(winStarProjectile, 1); //1 = skip spam protection
      clientgroup.getobject(0).play2D(rewardSound);
      $Tutorial::GoalsCompleted++;
      CommandToClient(clientgroup.getobject(0), 'BottomPrint', "<bitmap:base/client/ui/CI/trophy>\c3 Goal Completed! - Shooting - Time: " @ %time@"\n("@$Tutorial::TotalTargetsHit@"/"@$Tutorial::TotalTargetsLaunched@" targets hit with "@%percent@"% accuracy)",8,3);
      CommandToClient(clientgroup.getobject(0), 'CenterPrint', "", 0);
	openTutorialDoor(4);
   }
   else
      schedule(1000,0,"checkForEnd");
}

function launchTarget(%row,%speed,%type)
{
   if(!isObject(TutorialTargets))
      new SimGroup(TutorialTargets);
      
   if(%speed $= "")
      %speed = 1;

   if(strPos(%type,"m") >= 0)
	%data = TutorialTargetM;
   else
	%data = TutorialTarget;

   %target = new StaticShape()
   {
      dataBlock = %data;
      speed = %speed;
   };
   TutorialTargets.add(%target);
   
   if(%type $= "m4")
	%target.setSkinName("m3");
   else if(%type $= "m3")
	%target.setSkinName("m2");
   else if(%type $= "m2")
	%target.setSkinName("m1");
   else if(%type $= "m1")
	%target.setSkinName("base");

   if(%row == 1)
      %target.setTransform("-44.8628 -71.371 94.4225" SPC eulerToQuat("0 0 -90"));
   else if(%row == 2)
      %target.setTransform("-44.8628 -64.8711 94.4225" SPC eulerToQuat("0 0 -90"));
   else if(%row == 3)
      %target.setTransform("-44.8628 -58.8758 94.4225" SPC eulerToQuat("0 0 -90"));
      
   scrollTarget(%target);
}

function scrollTarget(%target)
{
   if(!isObject(%target))
      return;
      
   %pos = %target.getPosition();
   if(getWord(%pos,0) > -32)
   {
      %target.delete();
      return;
   }
   
   switch(%target.speed)
   {
      case 1:
      %moveAmmount = 0.06;
      %scheduleAmmount = 30;
      case 2:
      %moveAmmount = 0.08;
      %scheduleAmmount = 25;
      case 3:
      %moveAmmount = 0.09;
      %scheduleAmmount = 25;
      case 4:
      %moveAmmount = 0.1;
      %scheduleAmmount = 20;
      case 5:
      %moveAmmount = 0.17;
      %scheduleAmmount = 20;
   }
   
   %newPos = vectorAdd(%pos,%moveAmmount SPC "0 0");
   %target.setTransform(%newpos SPC rotFromTransform(%target.getPosition()));
   schedule(%scheduleAmmount,0,"scrollTarget",%target);
}

package TutorialParentingPackage
{
   function serverCmdSetWrenchData(%client,%fields)
   {
      for(%i=0;%i<getFieldCount(%fields);%i++)
      {
         %fieldName = firstWord(getField(%fields,%i));
         %fieldValue = getWord(getField(%fields,%i),1);
         if(%fieldName $= "VDB" && !$TutorialCompleted && $Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis")
         {
            if(%client.wrenchBrick.vehicleLimit !$= "")
               if(%client.wrenchBrick.vehicleLimit.getID() !$= %fieldValue.getID())
                  return;
         }
      }      
      Parent::serverCmdSetWrenchData(%client,%fields);
   }
   
   function ProjectileData::OnCollision(%this,%obj,%col,%pos,%norm,%fade,%vel)
   {
      if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted)
      {
         $Tutorial::TotalShotsFired++;
         if((%col.dataBlock $= "TutorialTarget" || %col.dataBlock $= "TutorialTargetM") && !%col.isDead)
         {
            serverplay3d(hammerhitsound,%pos);
            %col.isDead = 1;
            %hitDB = %col.dataBlock.getName()@"Hit";
            %col.setDataBlock(%hitDB);
            $Tutorial::TotalTargetsHit++;
         }
         else
         {
            Parent::onCollision(%this,%obj,%col,%pos,%norm,%fade,%vel);
         }
      }
      else
      {
         Parent::onCollision(%this,%obj,%col,%pos,%norm,%fade,%vel);
      }
   }

   function servercmdWand(%client)
   {
      if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted)
      {
         if(%client.player.canUseWand)
            Parent::serverCmdWand(%client);
      }
      else
         Parent::serverCmdWand(%client);
   }

   function servercmdMagicWand(%client)
   {
	   if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted)
      {
         if(%client.player.canUseWand)
            Parent::serverCmdMagicWand(%client);
      }
      else
         Parent::serverCmdMagicWand(%client);
   }

   function servercmdusespraycan(%client,%i)
   {
      if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted)
      {
         if(%client.player.canUseSpray)
            Parent::serverCmdusespraycan(%client,%i);
      }
      else
         Parent::serverCmdusespraycan(%client,%i);
   }

   function servercmdusefxcan(%client,%i)
   {
      if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted)
      {
         if(%client.player.canUseSpray)
            Parent::serverCmdusefxcan(%client,%i);
      }
      else
         Parent::serverCmdusefxcan(%client,%i);
   }

   function HammerImage::onHitObject(%this,%obj,%slot,%col,%pos,%norm)
   {
      if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted && %col.noBreak)
      {
         ServerPlay3d(HammerHitSound,%pos);
         return;
      }
      Parent::onHitObject(%this,%obj,%slot,%col,%pos,%norm);
   }

   function WandImage::onHitObject(%this,%obj,%slot,%col,%pos,%norm)
   {
	   if($Server::MissionFile $= "Add-Ons/Map_Tutorial/tutorial.mis" && !$TutorialCompleted && %col.noBreak)
	      return;
	   else
	      Parent::onHitObject(%this,%obj,%slot,%col,%pos,%norm);
   }

   function loadMission(%missionName, %isFirstMission)
   {
      if(%missionName !$= "Add-Ons/Map_Tutorial/tutorial.mis")
         schedule(10, 0, deActivatePackage, TutorialParentingPackage); //we probably don't want to de-activate a package while we're in it, so schedule it 
      
      Parent::loadMission(%missionName, %isFirstMission);
   }
};
activatePackage(TutorialParentingPackage);
