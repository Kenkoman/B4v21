package CustomMSPackage {
	function queryMasterTCPObj::onDisconnect(%this) {
		Parent::onDisconnect(%this);
		ServerInfoSO_DisplayAll();
	}
	function queryMasterTCPObj::onLine(%this,%line) {
		if(firstWord(%line) $= "NOTE") {
			if(removeWord(%line,0) $= $Pref::CustomMS::IgnoreNote) {
				warn("MS Note: " @ removeWord(%line,0));
				return;
			}
			$Pref::CustomMS::IgnoreNote = removeWord(%line,0);
			messageBoxOk("Announcement - CustomMS",removeWord(%line,0));
			return;
		}
		Parent::onLine(%this,%line);
	}
};
activatePackage(CustomMSPackage);
function ServerSO::Display(%this) {
	%selected = JS_serverList.getSelectedId();
	if(JS_serverList.getRowTextByID(%this.id) $= "") return;
	JS_serverList.removeRowById(%this.id);
	JS_serverList.addRow(%this.id, %this.serialize());
	if("JS_serverList".sortedNumerical) {
		JS_serverList.sortNumerical(JS_serverList.sortedBy, JS_serverList.sortedAsc);
	} else {
		JS_serverList.sort(JS_serverList.sortedBy, JS_serverList.sortedAsc);
	}
	JS_serverList.setSelectedById(%selected);
}
function ServerInfoSO_DisplayAll() {
	JS_serverList.clear();
	%TotalServerCount = 0;
	%TotalPlayerCount = 0;
	%i = 0;
	while(%i < $ServerSO_Count) {
		%obj = $ServerSO[%i];
		%TotalServerCount++;
		%TotalPlayerCount = %TotalPlayerCount + %obj.currPlayers;
		%doRow = 1;
		if($Pref::Filter::gameType != 0) {
			%version = getSubStr(%obj.name,2,strIPos(%obj.name,"]")-2);
			echo(atoi($Pref::Filter::gameType) SPC atoi(%version) SPC (atoi(%version) != atoi($Pref::Filter::gameType) ? "NO" : "YES"));
			if(atoi(%version) != atoi($Pref::Filter::gameType)) %doRow = 0;
		}
		if($Pref::Filter::Dedicated && %obj.ded !$= "Yes") %doRow = 0;
		if($Pref::Filter::NoPassword && %obj.pass $= "Yes") %doRow = 0;
		if($Pref::Filter::NotEmpty && %obj.currPlayers <= 0) %doRow = 0;
		if($Pref::Filter::NotFull && %obj.currPlayers >= %obj.maxPlayers) %doRow = 0;
		if(%obj.ping $= "Dead") %doRow = 0;
		if(%obj.ping !$= "???") if(%obj.ping > $pref::Filter::maxPing) %doRow = 0;
		if(%doRow) {
			%rowText = %obj.serialize();
			JS_serverList.addRow(%i, %rowText);
		}
		%i++;
	}
	%text = "";
	if(%TotalPlayerCount == 1) {
		%text = %TotalPlayerCount @ " Player / ";
	} else {
		%text = %TotalPlayerCount @ " Players / ";
	}
	if(%TotalServerCount == 1) {
		%text = %text @ %TotalServerCount @ " Server";
	} else {
		%text = %text @ %TotalServerCount @ " Servers";
	}
	JS_window.setText("Join Server - " @ %text);
}
function filtersGui::onWake() {
	Filter_MasterServer.setValue(getSubStr($Pref::MasterServer,0,(strIPos($Pref::MasterServer,":") != -1 ? strIPos($Pref::MasterServer,":") : strLen($Pref::MasterServer))));
	Filter_GameMenu.clear();
	for(%i=0;%i<getRecordCount($CustomMS::GameList);%i++) {
		%rec = getRecord($CustomMS::GameList,%i);
		Filter_GameMenu.add(getField(%rec,1),getField(%rec,0));
	}
	Filter_PingMenu.clear();
	Filter_PingMenu.add(50, 50);
	Filter_PingMenu.add(100, 100);
	Filter_PingMenu.add(150, 150);
	Filter_PingMenu.add(250, 250);
	Filter_PingMenu.add(450, 450);
	Filter_PingMenu.add(999, 999);
	Filter_GameMenu.setSelected(mFloor($pref::Filter::gameType));
	if(Filter_GameMenu.getTextByID(Filter_GameMenu.getSelected()) $= "") Filter_GameMenu.setSelected($version);
	Filter_PingMenu.setSelected(mFloor($pref::Filter::maxPing));
	if(Filter_PingMenu.getSelected() <= 0) Filter_PingMenu.setSelected(999);
}
function filtersGui::onSleep() {
	%master = trim(Filter_MasterServer.getValue());
	if(strIPos(%master,":") != -1) %master = getSubStr(%master,0,strIPos(%master,":"));
	if(%master $= "master2.blockland.us")
		messageBoxOk("Error - CustomMS","Failed to set master server. Reason:\n\nSetting the custom ms address to 'master2.blockland.us' can result in your key being revoked (if you host a server on it).");
	else
		$Pref::MasterServer = %master @ ":80";

	$pref::Filter::maxPing = Filter_PingMenu.getSelected();
	$pref::Filter::gameType = Filter_GameMenu.getSelected();
	if($JoinNetServer) ServerInfoSO_DisplayAll();
}
function CustomMS_GetGameList() {
	$CustomMS::GameList = "";
	echo("CustomMS: Getting game list...");
	if(isObject(CustomMS_TCP)) CustomMS_TCP.delete();
	%this      = new TCPObject(CustomMS_TCP);
	%this.url  = "pastebin.com";
	%this.port = "80";
	%this.path = "/raw/wgHbbwbz";
	%this.connect(%this.url @ ":" @ %this.port);
}
function CustomMS_ConnectionFailure() {
	error("ERROR: CustomMS_GetGameList() - Failed to connect to pastebin containing game list. Using pre-defined list.");
	$CustomMS::GameList =   "20	Blockland v20\n" @
				"19	Blockland v19\n" @
				"17	Blockland v17\n" @
				"16	Blockland v16\n" @
				"13	Blockland v13\n" @
				"8	Blockland v8\n" @
				"103	Blockland v1.03\n" @
				"2	Blockland v0002\n" @
				"1	GenericTDM\n" @
				"0	All\n";
}
function CustomMS_TCP::onConnectFailed(%this) {
	CustomMS_ConnectionFailure();
}
function CustomMS_TCP::onDNSFailed(%this) {
	CustomMS_ConnectionFailure();
}
function CustomMS_TCP::onConnected(%this) {
	%this.send("GET" SPC %this.path SPC "HTTP/1.1\r\nHost:" SPC %this.url @ "\r\nConnection: close\r\nUser-Agent: Blockland-r"@getBuildNumber()@"\r\n\r\n");
}
function CustomMS_TCP::onDisconnect(%this) {
	echo("CustomMS: Got " @ getRecordCount($CustomMS::GameList) @ " game" @ (getRecordCount($CustomMS::GameList) == 1 ? "" : "s"));
}
function CustomMS_TCP::onLine(%this,%line) {
	if(firstWord(%line) !$= "DEFINE") return;
	%line = removeWord(%line,0);
	$CustomMS::GameList = trim($CustomMS::GameList NL getField(%line,0) TAB getField(%line,1));
}
if(!filtersGui.isNewGui) {
	filtersGui.deleteAll();
	filtersGui.delete();
	exec("./filtersGui.gui");
	CustomMS_GetGameList();
}
exec("./script.cs");
exec("./patch.cs");