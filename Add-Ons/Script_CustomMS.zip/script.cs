if ($Pref::MasterServer $= "")
    $Pref::MasterServer = "b4v21.block.land:80";

function GetB4v21PatchVersion()
{
	if (!isFile("B4v21Patch.ver"))
		return "1.0";
	
	if ($B4v21::Version !$= "")
		return $B4v21::Version;
	
	%SO = new FileObject();
	%SO.openForRead("B4v21Patch.ver");
	%SO.readLine();
	%SO.readLine();
	$B4v21::Version = %SO.readLine();
	%SO.close();
	%SO.delete();
	
	return $B4v21::Version;
}

package enableCustomMS {
	function postServerTCPObj::connect(%this, %addr) {
		%oldLen   = strLen(getField(%this.cmd, getFieldCount(%this.cmd) - 1)) - 1;
		%this.cmd = strReplace(%this.cmd, "&Port=" @ mFloor($Server::Port), "&Port=" @ mFloor($Server::Port) @ "&Patch=1&ourName=" @ urlEnc($Pref::Player::NetName) @ "&GamePatch=" @ urlEnc(GetB4v21PatchVersion()));
		if (strPos(%this.cmd, "&ver=") != -1)
		{
			%this.cmd = getSubStr(%this.cmd, 0, strPos(%this.cmd, "&ver="));
			%this.cmd = strReplace(%this.cmd, "&Port=" @ mFloor($Server::Port),"&Port=" @ mFloor($Server::Port) @ "&ver=" @ $Version);
		}
		else
			%this.cmd = strReplace(%this.cmd, "&Port=" @ mFloor($Server::Port),"&Port=" @ mFloor($Server::Port) @ "&ver=" @ $Version);
		
		%newLen   = strLen(getField(%this.cmd, getFieldCount(%this.cmd) - 1)) - 1;
		%this.cmd = strReplace(%this.cmd, "Content-Length: " @ %oldLen, "Content-Length: " @ %newLen + 2);
        	%this.cmd = strReplace(%this.cmd, "master.blockland.us", $Pref::MasterServer);
		%this.cmd = strReplace(%this.cmd, "/master/postServer.asp", "/postServer.php");
		%this.cmd = %this.cmd @ "\r\n";
		Parent::connect(%this, $Pref::MasterServer);
	}
	
	function queryMasterTCPObj::connect(%this, %addr) {
		%this.cmd = "GET /index.php HTTP/1.1\r\nHost: " @ $Pref::MasterServer @ "\r\n\r\n";
		parent::connect(%this, $Pref::MasterServer);
	}
	
	function ServerInfoSO_Add(%ip, %pass, %ded, %name, %currPlayers, %maxPlayers, %mods, %map, %brickCount, %demoPlayers)
	{
		Parent::ServerInfoSO_Add(%ip, %pass, %ded, %name, %currPlayers, %maxPlayers, %mods, %map, %brickCount, %demoPlayers);
		%SO            = ServerInfoGroup.getObject(ServerInfoGroup.getCount() - 1);
		%SO.brickCount = %SO.map;
		%SO.map        = %SO.mods;
	}
};

activatePackage(enableCustomMS);

package B4v21AuthServer
{
	function authTCPObj_Client::connect(%this, %url)
	{
		%url           = strReplace(%url, "master.blockland.us", "b4v21.block.land");
		%this.cmd      = setWord(%this.cmd, 1, (strPos(%this.cmd, "authInit") != -1 ? "/api/authInit.php" : "/api/authConfirm2.php"));
		%this.cmd      = strReplace(%this.cmd, "master.blockland.us", "b4v21.block.land");
		%this.site     = "b4v21.block.land";
		%this.filePath = getWord(%this.cmd, 1);
		%isInit        = (strPos(%this.cmd, "authInit") != -1);
		
		// Revise the post data
		if (%isInit)
		{
			%PostData = getSubStr(getRecord(%this.cmd, getRecordCount(%this.cmd) - 1), 0, strLen(getRecord(%this.cmd, getRecordCount(%this.cmd) - 1)) - 1) @ "&VER=" @ $Version;
			%PostLen  = strLen(%PostData);
			
			// Set new post data
			%this.cmd = setRecord(%this.cmd, getRecordCount(%this.cmd) - 1, %PostData @ "\r");
			
			// Replace content length field
			for (%i = 0; %i < getRecordCount(%this.cmd); %i++)
			{
				if (getWord(getRecord(%this.cmd, %i), 0) !$= "Content-Length:")
					continue;
				
				%this.cmd = setRecord(%this.cmd, %i, "Content-Length:" SPC %PostLen @ "\r");
				break;
			}
		}
		
		Parent::connect(%this, %url);
	}
	function authTCPObj_Client::onLine(%this, %line)
	{
		switch$(firstWord(%line))
		{
			case "NOTE":
				%line = removeWord(%line, 0);
				
				if (!isObject(Canvas))
					echo("NOTE: " @ %line);
				else
					messageBoxOk("Authentication Server Notice", %line);
				
			default:
				Parent::onLine(%this, %line);
		}
	}
	function authTCPObj_Server::connect(%this, %url)
	{
		%url           = strReplace(%url, "master.blockland.us", "b4v21.block.land");
		%this.cmd      = setWord(%this.cmd, 1, (strPos(%this.cmd, "authInit") != -1 ? "/api/authInit.php" : "/api/authConfirm2.php"));
		%this.cmd      = strReplace(%this.cmd, "master.blockland.us", "b4v21.block.land");
		%this.site     = "b4v21.block.land";
		%this.filePath = getWord(%this.cmd, 1);
		%isInit        = (strPos(%this.cmd, "authInit") != -1);
		
		// Revise the post data
		if (%isInit)
		{
			%PostData = getSubStr(getRecord(%this.cmd, getRecordCount(%this.cmd) - 1), 0, strLen(getRecord(%this.cmd, getRecordCount(%this.cmd) - 1)) - 1) @ "&VER=" @ $Version;
			%PostLen  = strLen(%PostData);
			
			// Set new post data
			%this.cmd = setRecord(%this.cmd, getRecordCount(%this.cmd) - 1, %PostData @ "\r");
			
			// Replace content length field
			for (%i = 0; %i < getRecordCount(%this.cmd); %i++)
			{
				if (getWord(getRecord(%this.cmd, %i), 0) !$= "Content-Length:")
					continue;
				
				%this.cmd = setRecord(%this.cmd, %i, "Content-Length:" SPC %PostLen @ "\r");
				break;
			}
		}
		
		Parent::connect(%this, %url);
	}
	function servAuthTCPobj::connect(%this, %url)
	{
		%url      = strReplace(%url, "master.blockland.us", "b4v21.block.land");
		%this.cmd = setWord(%this.cmd, 1, "/api/authQuery.php");
		%this.cmd = strReplace(%this.cmd, "master.blockland.us", "b4v21.block.land");
		Parent::connect(%this, %url);
	}
};
activatepackage(B4v21AuthServer);