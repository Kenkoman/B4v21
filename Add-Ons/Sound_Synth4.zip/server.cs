//Server-side, 3D sound datablocks of the menu notes so you can build a piano

datablock AudioProfile(Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_00.wav";
	description = AudioClosest3d;
	preload = false;
};


datablock AudioProfile(Synth_01_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_01.wav";
};
datablock AudioProfile(Synth_02_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_02.wav";
};
datablock AudioProfile(Synth_03_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_03.wav";
};
datablock AudioProfile(Synth_04_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_04.wav";
};
datablock AudioProfile(Synth_05_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_05.wav";
};
datablock AudioProfile(Synth_06_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_06.wav";
};
datablock AudioProfile(Synth_07_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_07.wav";
};
datablock AudioProfile(Synth_08_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_08.wav";
};
datablock AudioProfile(Synth_09_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_09.wav";
};
datablock AudioProfile(Synth_10_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_10.wav";
};
datablock AudioProfile(Synth_11_Sound: Synth_00_Sound)
{
	filename = "base/data/sound/notes/Synth 4/Synth4_11.wav";
};