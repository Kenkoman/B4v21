//no jets at all
datablock PlayerData(PlayerNoJet : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "No-Jet Player";
	showEnergyBar = false;
};