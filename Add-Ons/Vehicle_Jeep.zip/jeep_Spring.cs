// jeep_spring.cs

datablock WheeledVehicleSpring(jeepSpring)
{
   // Wheel suspension properties
   length = 0.4;			 // Suspension travel
   force = 6000; //3000;		 // Spring force
   damping = 800; //600;		 // Spring damping
   antiSwayForce = 6; //3;		 // Lateral anti-sway force
};


