package DownloadInfo
{
    function updateBlobsRemaining(%blobsRemaining)
    {
        Parent::updateBlobsRemaining(%blobsRemaining);
        $blobsRemainingText = LoadingProgressTxt.getValue();
    }

    function updateDownloadProgress(%val)
    {
        Parent::updateDownloadProgress(%val);

        if ($currDownloadSize >= 1048576)
            %progressText = mFloatLength(%val              / 1048576, 1) @ " OF " @
                            mFloatLength($currDownloadSize / 1048576, 1) @ " MiB";
        else if ($currDownloadSize >= 1024)
            %progressText = mFloatLength(%val              / 1024, 1) @ " OF " @
                            mFloatLength($currDownloadSize / 1024, 1) @ " KiB";
        else
            %progressText = %val @ " OF " @ $currDownloadSize @ " bytes";

        LoadingProgressTxt.setValue($blobsRemainingText @ "   \x97   " @ %progressText);
    }
};

activatePackage(DownloadInfo);