MM_TutorialButton.command = "Tutorial_Prompt();"; //This changes the
						   //tutorial button's
						    //command called.

function Tutorial_Prompt() //This is the function new
			    //called by the tutorial
			     //button.
{
	MessageBoxYesNo("Tutorial", "Do you want to start the Blockland Tutorial?", "MM_Tutorial();");
			       //This is a message box with two options,
				//one to start the tutorial and the other
				 //to close the message box.
}