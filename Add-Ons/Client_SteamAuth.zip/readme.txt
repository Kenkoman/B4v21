Place steam_api.dll into the directory that the Blockland executable is in.

Place Client_SteamAuth.zip in your add-ons folder.

Place SteamAuth.dll in your modules folder (if one does not exist, make a folder named 'modules' in the directory that contains the Blockland executable)