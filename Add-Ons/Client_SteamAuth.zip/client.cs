if(!isObject(AccountInfo)) exec("Add-Ons/Client_SteamAuth/AccountInfo.gui");
if(!isObject(AuthTypeDlg)) exec("Add-Ons/Client_SteamAuth/AuthTypeDlg.gui");

package SteamAuth_TempPackage {
	function MM_AuthBar::onWake(%this) {
		Parent::onWake(%this);

		if(!isObject(keyGui_SAM)) {
			%tmp = new GuiBitmapButtonCtrl(keyGui_SAM) {
				profile = "BlockButtonProfile";
				horizSizing = "center";
				vertSizing = "top";
				position = "112 2";
				extent = "129 20";
				minExtent = "8 2";
				visible = "1";
				command = "AccountInfo.switchAuthMethod();";
				text = "Switch auth method";
				groupNum = "-1";
				buttonType = "PushButton";
				bitmap = "base/client/ui/button1";
				lockAspectRatio = "0";
				alignLeft = "0";
				overflowImage = "0";
				mKeepCached = "0";
				mColor = "255 255 255 255";
				wrap = "0";
			};
			keyGui.getObject(0).add(%tmp);
		}
		
		deactivatePackage(SteamAuth_TempPackage);
	}
};activatePackage(SteamAuth_TempPackage);

function isServerDedicated() {
	if($CACHE::Dedicated !$= "") return $CACHE::Dedicated;
	
	for(%i=0;%i<$Game::argc;%i++) { if($Game::argv[%i] $= "-dedicated") { $CACHE::Dedicated = 1; return 1; } }
	
	return 0;
}

function steamSetInfo() {
	if($Pref::Steam::Name !$= "" && $Pref::Steam::BLID !$= "") {
		$Pref::Player::NetName = $Pref::Steam::Name;
		setAuthInfo($Pref::Steam::BLID, $Pref::Player::NetName);
		setAuthInfo($Pref::Steam::BLID, $Pref::Player::NetName);
		
		if(!isServerDedicated()) {
			MM_AuthText.setText("Welcome, " @ $Pref::Steam::Name);
			MM_AuthBar.blinkSuccess();
			MM_UpdateDemoDisplay();
			JS_QueryInternetBlocker.setVisible(0);
			Canvas.popDialog(AccountInfo);
		}
	}
}

function steamDoInit() {
	if(!isFunction(attachModule)) %error = "Failed to initialize Steam (You are not using BlocklandLoader-20)";
	
	if(!isFunction(SteamAPI_Init)) {
		attachModule("SteamAuth.dll");
		if(!isFunction(SteamAPI_Init)) %error = "Failed to initialize Steam (Could not load SteamAuth.dll -- You need to have steam_api.dll in the folder that Blockland.exe is in.)";
	}
	
	if(%error !$= "") {
		if(isObject(Canvas)) messageBoxOK("Blockland - Error", %error);
		else error(%error);
		
		return;
	}
	
	$UseSteam = 1;
	
	if(!isServerDedicated()) {
		MM_AuthKeyButton.setText("Info");
		Canvas.popDialog(KeyGUI);
		Canvas.pushDialog(AccountInfo);
	}
	
	if(isUnlocked()) auth_Init_Steam();
}

package SteamAPIPackage {
	function KeyGUI::onWake(%this) {
		Parent::onWake(%this);
		if(!isUnlocked()) {
			if($Pref::Client::AuthMethod $= "") Canvas.pushDialog(AuthTypeDlg);
			else if($Pref::Client::AuthMethod $= "Steam") {
				steamDoInit();
				steamSetInfo();
			}
		}
	}
	
	function keyGui::changePrompt(%this) {
		// Called when the Key button is pressed on the main menu
		if($UseSteam) {
			Canvas.pushDialog(AccountInfo);
			return;
		}
		Parent::changePrompt(%this);
	}
};
activatePackage(SteamAPIPackage);

function AuthTypeDlg::onWake(%this) {
	%w = %this.getObject(0);
	%w.resize((getWord(getRes(), 0)/2)-(getWord(%w.getExtent(), 0)/2), (getWord(getRes(), 1)/2)-(getWord(%w.getExtent(), 1)/2), getWord(%w.getExtent(), 0), getWord(%w.getExtent(), 1));
}

function AuthTypeDlg::choose(%this, %choice, %confirm) {
	if(!AuthTypeDlg.isAwake()) return;
	
	switch(%choice) {
		case 0: // Regular
			if(!%confirm) {
				messageBoxYesNo("Confirmation - Blockland", "Are you sure you want to use regular authentication?", "AuthTypeDlg.choose(0, 1);");
				return;
			}
			
			if($Pref::Client::AuthMethod $= "Steam") {
				$Pref::Steam::UserName    = "";
				$Pref::Steam::BLID        = "";
				$Pref::Client::AuthMethod = "Regular";
				export("$Pref::*", "config/client/prefs.cs");
				
				if(%confirm != 2) {
					messageBoxYesNo("Confirmation - Blockland", "You have already chosen Steam Authentication, so Blockland will have to restart in order to use regular authentication. Do you want to restart now?", "restartBlockland(1);");
					return;
				}
				
				return;
			}
			
			Canvas.popDialog(%this);
			messageBoxOK("Steam Auth - Blockland", "You will be regularly authenticated from now on.");
			$Pref::Client::AuthMethod = "Regular";
		case 1: // Steam
			if(!%confirm) {
				messageBoxYesNo("Confirmation - Blockland", "Are you sure you want to use Steam authentication?", "AuthTypeDlg.choose(1, 1);");
				return;
			}
			
			if($Pref::Client::AuthMethod $= "Regular") {
				if(%u = isUnlocked()) {
					$Pref::Steam::UserName    = $Pref::Player::NetName;
					$Pref::Steam::BLID        = getNumKeyID();
				}
				
				$Pref::Client::AuthMethod = "Steam";
				export("$Pref::*", "config/client/prefs.cs");
				
				steamDoInit();
				
				if(%u) {
					setAuthInfo($Pref::Steam::BLID, $Pref::Player::NetName);
					setAuthInfo($Pref::Steam::BLID, $Pref::Player::NetName);
				}
			}
			
			Canvas.popDialog(%this);
			messageBoxOK("Steam Auth - Blockland", "You will be authenticated with Steam from now on.");
			$Pref::Client::AuthMethod = "Steam";
			steamDoInit();
		default:
			messageBoxOK("??? - Blockland", "Affirmative. We will set your authentication method to... uhm... How did you even do that? This time, choose between the only two options.");
			return;
	}
}

function AccountInfo::onWake(%this) {
	%w = %this.getObject(0);
	%w.resize((getWord(getRes(), 0)/2)-(getWord(%w.getExtent(), 0)/2), (getWord(getRes(), 1)/2)-(getWord(%w.getExtent(), 1)/2), getWord(%w.getExtent(), 0), getWord(%w.getExtent(), 1));
	
	SteamBL_Name.setValue("");
	SteamBL_BLID.setValue("");
	SteamBL_SteamName.setText("<just:center>SteamAuth Version: " @ getSteamAuthVersion());
}

function AccountInfo::switchAuthMethod(%this) {
	Canvas.popDialog(%this);
	Canvas.pushDialog(AuthTypeDlg);
}

function AccountInfo::submit(%this) {
	%name = SteamBL_Name.getValue();
	%blid = SteamBL_BLID.getValue();
	
	if(%name $= "" || %blid $= "" || stripChars(%blid, "0123456789") !$= "") {
		messageBoxOK("Error - Blockland", "Invalid BL_ID or name.");
		return;
	}
	
	if(!setAuthInfo(%blid, %name)) {
		messageBoxOK("Error - Blockland", "There was a problem setting your credentials. Please check the console for more details.");
		
		return;
	}
	
	$Pref::Player::NetName = %name;
	$Pref::Steam::Name     = %name;
	$Pref::Steam::BLID     = %blid;
	
	Canvas.popDialog(AccountInfo);
	setAuthInfo(%blid, %name);
	auth_Init_Steam();
	MM_UpdateDemoDisplay();
	JS_QueryInternetBlocker.setVisible(0);
	export("$Pref::*", "config/client/prefs.cs");
}

function onSteamAuthFailure(%reason) {
	if(!isServerDedicated()) Canvas.pushDialog(AccountInfo);
	
	switch$(%reason) {
		case "no user":
			if(!isServerDedicated()) messageBoxOK("Blockland", "The B4v21 auth server could not verify the credentials you provided. This could be caused by the following:\n\n+ You haven't authed on Blockland v21 recently; Open up Blockland v21 on Steam and wait for the bar at the bottom of the main menu to say, \"Welcome, (your name)\"\n\n+ You provided fake credentials\n\n+ The auth server is down");
			else error("The B4v21 auth server could not verify the credentials you provided. This could be caused by the following:\r\n\r\n+ You haven't authed on Blockland v21 recently; Open up Blockland v21 on Steam and wait for the bar at the bottom of the main menu to say, \"Welcome, (your name)\"\r\n\r\n+ You provided fake credentials\r\n\r\n+ The auth server is down");
			%text = "Invalid Credentials";
		default: %text = "Auth server issue";
	}
	
	lock();
	
	if(!isServerDedicated()) {
		MM_AuthText.setText("AUTH FAILED: " @ %text);
		MM_AuthText.schedule(2000, setText, "Demo Mode");
		MM_AuthBar.blinkFail();
		
		MM_UpdateDemoDisplay();
	}
}

function onSteamAuthSuccess() {
	unlock();
	
	if(!isServerDedicated()) {
		MM_AuthText.setText("Welcome, " @ $Pref::Steam::Name);
		MM_AuthBar.blinkSuccess();
		
		MM_UpdateDemoDisplay();
	} else {
		WebCom_PostServer();
		pingMatchMakerLoop();
	}
}

function auth_Init_Steam() {
	// Get the matchmaker token & IP, along with the CDNURL, PreviewURL, and our IP (provided that the credentials we gave are valid)
	echo("Authentication: Connecting...");
	
	%postText = "Name=" @ $Pref::Steam::Name @ "&BLID=" @ $Pref::Steam::BLID;
	
	if(isObject(steamAuthTCPObj)) steamAuthTCPObj.delete();
	%TCP = new TCPObject(steamAuthTCPObj);
	%TCP.passPhraseCount = 0;
	%TCP.site = "clayhanson.x10host.com";
	%TCP.port = 80;
	%TCP.done = 0;
	%TCP.success = 0;
	%TCP.filePath = "/master/authBlockland.php";
	%TCP.postText = %postText;
	%TCP.postTextLen = strlen(%postText);
	%TCP.cmd = "POST " @ steamAuthTCPObj.filePath @ " HTTP/1.0\r\n" @ "Host: " @ steamAuthTCPObj.site @ "\r\n" @ "User-Agent: Blockland-r" @ getBuildNumber() @ "\r\n" @ "Content-Type: application/x-www-form-urlencoded\r\n" @ "Content-Length: " @ steamAuthTCPObj.postTextLen @ "\r\n" @ "\r\n" @ steamAuthTCPObj.postText @ "\r\n";
	%TCP.connect(steamAuthTCPObj.site @ ":" @ steamAuthTCPObj.port);
}

function steamAuthTCPObj::onDNSFailed(%this) {
	echo((isServerDedicated() ? "Server" : "Client") SPC "Auth DNS Failed");
	
	if(isServerDedicated()) return;
	
	if(isUnlocked()) {
		MM_AuthText.setText("Offline Mode (DNS Failed)");
		MM_AuthBar.blinkSuccess();
	} else {
		MM_AuthText.setText("Demo Mode");
		MM_AuthBar.blinkFail();
	}
}

function steamAuthTCPObj::onConnectFailed(%this) {
	%this.retryCount++;
	
	if(isServerDedicated()) {
		if(%this.retryCount > 3) {
			echo("Authentication FAILURE: Failed to connect");
		} else {
			echo("Retrying server auth...");
			%this.schedule(5000, connect, %this.site @ ":" @ %this.port);
		}
		
		return;
	}
	
	if(%this.retryCount > %maxRetries) {
		if(isUnlocked()) {
			echo("Client Steam auth connection failed, setting demo mode");
			MM_AuthText.setText("Offline Mode");
			MM_AuthBar.blinkSuccess();
		} else {
			echo("Client Steam auth failed, setting demo mode");
			MM_AuthText.setText("Demo Mode");
			MM_AuthBar.blinkFail();
		}
	} else {
		echo("Retrying client auth...");
		MM_AuthText.setText("Retrying connection...");
		%this.schedule(5000, connect, %this.site @ ":" @ %this.port);
	}
}

function steamAuthTCPObj::onConnected(%this) {
	%this.send(%this.cmd);

	if(!isServerDedicated()) MM_AuthText.setText("Authentication: Validating credentials...");
}

function steamAuthTCPObj::onDisconnect(%this) {
}

function steamAuthTCPObj::onLine(%this, %line) {
	switch$(firstWord(%line)) {
		case "MMTOK":		setMatchMakerToken(getWord(%line, 1));
		case "MATCHMAKER":	setMatchMakerIP(getWord(%line, 1));
		case "CDNURL":		setCDNURL(getWord(%line, 1));
		case "PREVIEWURL":	setPreviewURL(getWord(%line, 1));
		case "PREVIEWWORK":	setRayTracerWork(getWord(%line, 1));
		case "YOURIP":		$MyTCPIPAddress = getWord(%line, 1);
		case "FAIL":		echo("\c2Authentication FAILURE: " @ (%reason = restWords(%line))); onSteamAuthFailure(%reason);
		case "SUCCESS":		echo("Authentication: SUCCESS"); onSteamAuthSuccess();
	}
}

if(isFunction(onSteamAuthLoaded)) onSteamAuthLoaded();