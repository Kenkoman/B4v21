package loadingEscapeMenu
{
	function escapeMenu::toggle( %this )
	{
		if ( canvas.getContent() $= loadingGUI.getID() )
		{
			if ( %this.isAwake() )
			{
				canvas.popDialog( %this );
			}
			else
			{
				canvas.pushDialog( %this );
			}
		}
		else
		{
			parent::toggle( %this );
		}
	}
};

activatePackage( "loadingEscapeMenu" );
