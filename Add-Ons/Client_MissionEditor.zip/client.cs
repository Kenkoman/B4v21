echo("\n--------- Initializing MOD: Editor ---------");
exec("./editor.cs");
exec("./particleEditor.cs");
exec("./GuiEditorGui.gui");
exec("./ParticleEditor.gui");