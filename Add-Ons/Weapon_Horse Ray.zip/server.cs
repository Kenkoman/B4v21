//we need the horse add-on for this, so force it to load
%error = ForceRequiredAddOn("Vehicle_Horse");

if(%error == $Error::AddOn_Disabled)
{
   //A bit of a hack:
   //  we just forced the horse to load, but the user had it disabled
   //  so lets make it so they can't select it
   HorseArmor.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   //we don't have the horse, so we're screwed
   error("ERROR: Weapon_HorseRay - required add-on Vehicle_Horse not found");
}
else
{
   exec("./Weapon_HorseRay.cs"); 
}
