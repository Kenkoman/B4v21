function validateFOV() {
	setFov(SliderFOV.getValue());
	$Pref::Player::DefaultFOV = SliderFOV.getValue();
}
function initFOVFix() {
	if($FOVInit) return;
	$FOVInit = 1;
	%text = new GuiTextCtrl() {
		profile = "GuiTextProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "235 141";
		extent = "25 18";
		minExtent = "8 2";
		visible = "1";
		text = "FOV:";
		maxLength = "255";
	};
	%slider = new GuiSliderCtrl(SliderFOV) {
		profile = "GuiSliderProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "265 141";
		extent = "310 30";
		minExtent = "8 8";
		visible = "1";
		range = "70.000000 140.000000";
		ticks = "32";
		command = "validateFOV();";
		snap = "0";
	};
	OptAdvGraphicsPane.getObject(2).getObject(0).getObject(0).add(%text);
	OptAdvGraphicsPane.getObject(2).getObject(0).getObject(0).add(%slider);
}
initFOVFix();