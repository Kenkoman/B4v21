if($Pref::MasterServer $= "")
 $Pref::MasterServer = "b4v21.block.land:80";


package CustomMSPackage {
	function authTCPObj_Client::disconnect(%this) {
		Parent::disconnect(%this);
		if($AuthingKey == 2) $AuthingKey = 0;
		if($AuthingKey != 1) return;
		$AuthingKey = 2;
		schedule(100,0,auth_Init_Client_Real);
	}
	function servAuthTCPObj::connect(%this, %address) {
		%this.cmd = strReplace(%this.cmd, %this.filePath, "/authQuery.php");
		%this.cmd = strReplace(%this.cmd, %this.site, "auth.blockland.us");
		Parent::connect(%this, %address);
	}
	function postServerTCPObj::connect(%this, %addr) {

		%oldPostLen = strLen(getRecord(%this.cmd, %ridx = (getRecordCount(%this.cmd) - 1)));
		
		%this.cmd = strReplace(%this.cmd, %this.filePath, "/postServer.php");
		%this.cmd = strReplace(%this.cmd, %this.site, $Pref::MasterServer);
		%this.cmd = setRecord(%this.cmd, %ridx, getRecord(%this.cmd, %ridx) @ "&Patch=1&ourName=" @ urlEnc(trim($Pref::Player::NetName)));
		
		for(%i=0;%i<getRecordCount(%this.cmd);%i++) {
			if(getWord(getRecord(%this.cmd, %i), 0) !$= "Content-Length:") continue;
			%this.cmd = setRecord(%this.cmd, %i, "Content-Length: " @ strLen(getRecord(%this.cmd, %rIdx)));
			break;
		}
		
		Parent::Connect(%this, $Pref::MasterServer);

	}


	function queryMasterTCPObj::connect(%this, %addr) {
		%oldLen = strLen(getField(%this.cmd,getFieldCount(%this.cmd)-1))-1;
		%this.cmd = "GET /index.php HTTP/1.0\r\nHost: " @ $Pref::MasterServer @ "\r\n\r\n";
		%this.cmd = strReplace(%this.cmd, %this.site, $Pref::MasterServer);

		parent::connect(%this, $Pref::MasterServer);

	}
	function AutoUpdateGui::onWake(%this) {
		Parent::onWake(%this);
		Canvas.popDialog(%this);
	}
	function MM_AuthText::setText(%this, %text) {
		if(%text $= "Authentication: Validating key...") {
			if($AuthingKey != 0) { Parent::setText(%this, %text); return; }
			$AuthingKey = 1;
			$oldver = $version;
			$version = "21";
			auth_Init_Client_Real();
			return;
		}
		Parent::setText(%this, %text);
	}
	function MM_AuthBar::blinkSuccess(%this) {
		Parent::blinkSuccess(%this);
		if(!$AuthingKey) return;
		$version = $oldver;
		$AuthingKey = 0;
	}
};
activatePackage(CustomMSPackage);


function patchTCPObj::onBinChunk(%this) {
    %this.disconnect();
    %this.schedule(1,delete);
    AutoUpdateGUI.delete();
}
function auth_Init_Client_Real() {
	authTCPObj_Client.site = "auth.blockland.us";
	authTCPObj_Client.port = 80;
	if($AuthingKey == 0) $AuthingKey = 1;
	switch($AuthingKey) {
		case 1:
			authTCPObj_Client.passPhraseCount = 0;
			authTCPObj_Client.done = 0;
			authTCPObj_Client.success = 0;
			authTCPObj_Client.filePath = "/authInit.php";
			%postText = "ID=" @ getKeyID();
			%N = getNonsense("86");
			%postText = %postText @ "&N="@%N;
			%postText = %postText @ "&VER="@$version;
			authTCPObj_Client.postText = %postText;
			authTCPObj_Client.postTextLen = strlen(%postText);
			authTCPObj_Client.cmd = "POST " @ authTCPObj_Client.filePath @ " HTTP/1.0\r\n" @ "Host: " @ authTCPObj_Client.site @ "\r\n" @ "User-Agent: Blockland-r" @ (isFunction(getBuildNumber) ? getBuildNumber() : "1988") @ "\r\n" @ "Content-Type: application/x-www-form-urlencoded\r\n" @ "Content-Length: " @ authTCPObj_Client.postTextLen @ "\r\n" @ "\r\n" @ authTCPObj_Client.postText @ "\r\n";
			authTCPObj_Client.connect(authTCPObj_Client.site @ ":" @ authTCPObj_Client.port);
		case 2:
			authTCPObj_Client.cmd = strReplace(authTCPObj_Client.cmd,authTCPObj_Client.filePath,"/authConfirm2.php");
			authTCPObj_Client.connect(authTCPObj_Client.site @ ":" @ authTCPObj_Client.port);
	}
}
function clientCmdOpenPrintSelectorDlg(%aspectRatio, %startPrint, %numPrints) {
	if(PSD_Window.scrollcount $= "") PSD_Window.scrollcount = 0;
	if(!isObject("PSD_PrintScroller" @ %aspectRatio)) PSD_LoadPrints(%aspectRatio, %startPrint, %numPrints);
	if(!isObject("PSD_PrintScrollerLetters")) PSD_LoadPrints("Letters", $PSD_letterStart, $PSD_numLetters);
	$PSD_NumPrints = %numPrints;
	Canvas.pushDialog("printSelectorDlg");
	if($PSD_LettersVisible || $PSD_NumPrints == 0)
		PSD_PrintScrollerLetters.setVisible(1);
	else {
		%obj = "PSD_PrintScroller" @ %aspectRatio;
		%obj.setVisible(1);
	}
	$PSD_CurrentAR = %aspectRatio;
}