//particles_FX Cans
//the datablocks for these particles are part of the game, this file just changes them slightly to make them placeable with the wrench


blinkPaintEmitter.uiName = "FX Can - Blink";
chromePaintEmitter.uiName = "FX Can - Chrome";
flatPaintEmitter.uiName = "FX Can - Flat";
glowPaintEmitter.uiName = "FX Can - Glow";
jelloPaintEmitter.uiName = "FX Can - Undulo";
rainbowPaintEmitter.uiName = "FX Can - Rainbow";
pearlPaintEmitter.uiName = "FX Can - Pearl";
stablePaintEmitter.uiName = "FX Can - Stable";
swirlPaintEmitter.uiName = "FX Can - Swirl";