%errorA = ForceRequiredAddOn("Vehicle_Jeep");
%errorB = ForceRequiredAddOn("Weapon_Rocket_Launcher");
%errorC = ForceRequiredAddOn("Projectile_GravityRocket");

if(%errorA == $Error::AddOn_Disabled)
   JeepVehicle.uiName = "";
if(%errorB == $Error::AddOn_Disabled)
   rocketLauncherItem.uiName = "";
if(%errorC == $Error::AddOn_Disabled)
   gravityRocketProjectile.uiName = "";

if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_Tank - required add-on Vehicle_Jeep not found");
else if(%errorB == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_Tank - required add-on Weapon_Rocket_Launcher not found");
else if(%errorC == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_Tank - required add-on Projectile_GravityRocket not found");
else
   exec("./Vehicle_Tank.cs"); 