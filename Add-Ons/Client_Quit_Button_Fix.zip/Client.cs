MM_QuitButton.command = "Quit_Prompt();"; //This changes the
					   //quit button's command
					    //called.

function Quit_Prompt() //This is the function new called by the quit
			//button.
{
	MessageBoxYesNo("Quit", "Are you sure you want to exit Blockland?", "quit();"); //This is a message box with two options,
			  //one to start the tutorial and the other
			   //to close the message box.
}