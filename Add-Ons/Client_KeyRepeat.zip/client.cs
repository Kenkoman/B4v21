
package KeyRepeat{
	function GuiControl::onWake(%this){
		if(isFunction(%this::onWake)) parent::onWake(%this);
		
		deactivateKeyboard();
	}
};
activatePackage(KeyRepeat);
