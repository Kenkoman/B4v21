$Pref::AdminGui::DuplicatorBtn = true;           //> Whether to display the duplicator button

if(isObject(AdminGui) && !isObject(Btn_Fetch) && !isObject(Btn_Find) && !isObject(Btn_Duplicator))
{
	$AdminGuiWindow = AdminGui.getObject(0);
	new GuiBitmapButtonCtrl(Btn_Fetch)
	{
		profile = "BlockButtonProfile";
		horizSizing = "left";
		vertSizing = "bottom";
		position = "205 156";
		extent = "99 19";
		minExtent = "8 2";
		visible = "1";
		command = "AdminGui::Fetch();";
		text = "Fetch";
		groupNum = "-1";
		buttonType = "PushButton";
		bitmap = "base/client/ui/button1";
		lockAspectRatio = "0";
		alignLeft = "0";
		overflowImage = "0";
		mKeepCached = "0";
		mColor = "206 240 216 255";
	};
	$AdminGuiWindow.add(Btn_Fetch);
	new GuiBitmapButtonCtrl(Btn_Find)
	{
		profile = "BlockButtonProfile";
		horizSizing = "left";
		vertSizing = "bottom";
		position = "205 176";
		extent = "99 19";
		minExtent = "8 2";
		visible = "1";
		command = "AdminGui::Find();";
		text = "Find";
		groupNum = "-1";
		buttonType = "PushButton";
		bitmap = "base/client/ui/button1";
		lockAspectRatio = "0";
		alignLeft = "0";
		overflowImage = "0";
		mKeepCached = "0";
		mColor = "0 255 255 255";
	};
	$AdminGuiWindow.add(Btn_Find);
	if($Pref::AdminGui::DuplicatorBtn)
	{
		new GuiBitmapButtonCtrl(Btn_Duplicator)
		{
			profile = "BlockButtonProfile";
			horizSizing = "left";
			vertSizing = "bottom";
			position = "205 198";
			extent = "98 38";
			minExtent = "8 2";
			visible = "1";
			command = "AdminGui::Duplicator();";
			text = "Duplicator";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "base/client/ui/button1";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			mKeepCached = "0";
			mColor = "0 255 0 255";
		};
		$AdminGuiWindow.add(Btn_Duplicator);
	}
}

function AdminGui::Fetch()
{
	%victim = getField(lstAdminPlayerList.getRowTextByID(lstAdminPlayerList.getSelectedID()), 0);
	commandtoserver('Fetch', %victim);
	canvas.popDialog(AdminGui);
	canvas.popDialog(escapeMenu);
}

function AdminGui::Find()
{
	%victim = getField(lstAdminPlayerList.getRowTextByID(lstAdminPlayerList.getSelectedID()), 0);
	commandtoserver('Find', %victim);
	canvas.popDialog(AdminGui);
	canvas.popDialog(escapeMenu);
}

function AdminGui::Duplicator()
{
	commandtoserver('Duplicator');
	canvas.popDialog(AdminGui);
	canvas.popDialog(escapeMenu);
}